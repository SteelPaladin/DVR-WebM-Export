#include "vp9_alpha_encoder.h"

#include <algorithm>
#include <chrono>
#include <cctype>
#include <cstring>
#include <string>
#include <vector>

#include "diag_log.h"

extern "C" {
#include <libavutil/imgutils.h>
#include <libavutil/opt.h>
#include <libavutil/pixdesc.h>
}

namespace webmalpha {

namespace {

struct FormatDesc {
    const char* name;
    uint32_t colorModel;
};

const FormatDesc kFormats[kInputFormatCount] = {
    {"VP9 Alpha (RGBA)", clrRGBA},
    {"VP9 Alpha (AYUV 4:4:4)", clrAYUV},
};

std::string ErrStr(int err) {
    char buf[AV_ERROR_MAX_STRING_SIZE] = {0};
    av_strerror(err, buf, sizeof(buf));
    return buf;
}

int32_t GetIntSetting(IPropertyProvider* props, const char* key, int32_t fallback) {
    int32_t v = fallback;
    if (props && props->GetINT32(key, v)) return v;
    return fallback;
}

int SwsColorspaceFromMatrix(int16_t matrix) {
    switch (matrix) {
        case 5:   // BT.470BG
        case 6:   // SMPTE 170M
            return SWS_CS_ITU601;
        case 9:   // BT.2020 NCL
        case 10:  // BT.2020 CL
            return SWS_CS_BT2020;
        case 1:  // BT.709
        default:
            return SWS_CS_ITU709;
    }
}

std::string Lower(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c) { return std::tolower(c); });
    return s;
}

// Container list strings: NUL-separated. Each entry we offer must refer to
// our own WebM container.
std::string BuildContainerList() {
    char hex[33];
    for (int i = 0; i < 16; ++i) snprintf(hex + i * 2, 3, "%02x", kContainerUUID[i]);
    const std::vector<std::string> entries = {
        kContainerUUIDDashed,          // 6A1E0B57-...-9E20
        Lower(kContainerUUIDDashed),  // 6a1e0b57-...-9e20
        hex,                           // 6a1e0b573c2d...
    };
    std::string out;
    for (size_t i = 0; i < entries.size(); ++i) {
        out += entries[i];
        if (i + 1 < entries.size()) out.push_back('\0');
    }
    return out;
}

bool IsOurContainer(const std::string& container) {
    if (container.empty()) return true;  // not told; assume ours
    const std::string c = Lower(container);
    char hex[33];
    for (int i = 0; i < 16; ++i) snprintf(hex + i * 2, 3, "%02x", kContainerUUID[i]);
    return c.find(Lower(kContainerUUIDDashed)) != std::string::npos || c.find(hex) != std::string::npos ||
           c.find("webm") != std::string::npos;
}

}  // namespace

// ---------------------------------------------------------------------------
// Registration
// ---------------------------------------------------------------------------

StatusCode Vp9AlphaEncoder::RegisterCodecs(HostListRef* list) {
    const std::string containers = BuildContainerList();

    for (uint8_t i = 0; i < kInputFormatCount; ++i) {
        HostPropertyCollectionRef info;
        if (!info.IsValid()) return errAlloc;

        uint8_t uuid[16];
        memcpy(uuid, kCodecUUID, 16);
        uuid[15] = static_cast<uint8_t>(uuid[15] + i);
        info.SetProperty(pIOPropUUID, propTypeUInt8, uuid, 16);

        const char* group = "WebM Alpha";
        info.SetProperty(pIOPropGroup, propTypeString, group, static_cast<int>(strlen(group)));
        info.SetProperty(pIOPropName, propTypeString, kFormats[i].name, static_cast<int>(strlen(kFormats[i].name)));

        const uint32_t fourCC = 'vp09';
        info.SetProperty(pIOPropFourCC, propTypeUInt32, &fourCC, 1);

        const uint32_t media = mediaVideo;
        info.SetProperty(pIOPropMediaType, propTypeUInt32, &media, 1);
        const uint32_t dir = dirEncode;
        info.SetProperty(pIOPropCodecDirection, propTypeUInt32, &dir, 1);

        info.SetProperty(pIOPropColorModel, propTypeUInt32, &kFormats[i].colorModel, 1);
        const uint8_t sub = 1;
        info.SetProperty(pIOPropHSubsampling, propTypeUInt8, &sub, 1);
        info.SetProperty(pIOPropVSubsampling, propTypeUInt8, &sub, 1);

        const uint32_t bitDepth = 8;
        info.SetProperty(pIOPropBitDepth, propTypeUInt32, &bitDepth, 1);
        info.SetProperty(pIOPropBitsPerSample, propTypeUInt32, &bitDepth, 1);

        // Video range first (= default): what browsers expect from VP9.
        const uint8_t dataRange[] = {0, 1};
        info.SetProperty(pIOPropDataRange, propTypeUInt8, dataRange, 2);

        const uint32_t noReorder = 0;
        info.SetProperty(pIOPropTemporalReordering, propTypeUInt32, &noReorder, 1);

        const uint8_t fields = fieldProgressive;
        info.SetProperty(pIOPropFieldOrder, propTypeUInt8, &fields, 1);

        // Stateful encoder: frames must arrive in order, one at a time.
        const uint8_t threadSafe = 0;
        info.SetProperty(pIOPropThreadSafe, propTypeUInt8, &threadSafe, 1);
        const uint8_t hwAcc = 0;
        info.SetProperty(pIOPropHWAcc, propTypeUInt8, &hwAcc, 1);

        // THE important line: tells Resolve this codec carries alpha, which is
        // what makes the "Export Alpha" checkbox appear on the Deliver page.
        const uint8_t hasAlpha = 1;
        info.SetProperty(pIOPropHasAlpha, propTypeUInt8, &hasAlpha, 1);

        info.SetProperty(pIOPropContainerList, propTypeString, containers.c_str(),
                         static_cast<int>(containers.size()));

        if (!list->Append(&info)) return errFail;
        Log("Registered codec '%s' (uuid ...%02X)", kFormats[i].name, uuid[15]);
    }
    return errNone;
}

StatusCode Vp9AlphaEncoder::GetEncoderSettings(InputFormat format, HostPropertyCollectionRef* values,
                                               HostListRef* settingsList) {
    const int32_t mode = GetIntSetting(values, kSettingMode, kDefaultMode);
    const int32_t crf = GetIntSetting(values, kSettingCrf, kDefaultCrf);
    const int32_t speed = GetIntSetting(values, kSettingSpeed, kDefaultSpeed);
    const int32_t keyint = GetIntSetting(values, kSettingKeyint, kDefaultKeyint);

    {
        HostUIConfigEntryRef item(kSettingMode);
        item.MakeComboBox("Encoder Mode", {"Fast", "Quality (slow)"}, {kModeFast, kModeQuality}, mode);
        item.SetTriggersUpdate(true);  // show/hide the speed slider
        if (!item.IsSuccess() || !settingsList->Append(&item)) return errFail;
    }
    {
        HostUIConfigEntryRef item(kSettingCrf);
        item.MakeSlider("Quality (CRF)", "lower = better", crf, 0, 63, kDefaultCrf);
        if (!item.IsSuccess() || !settingsList->Append(&item)) return errFail;
    }
    {
        HostUIConfigEntryRef item(kSettingSpeed);
        item.MakeSlider("Encode Speed", "0 slowest/best, 5 fastest", std::min(speed, 5), 0, 5, kDefaultSpeed);
        item.SetHidden(mode != kModeQuality);
        if (!item.IsSuccess() || !settingsList->Append(&item)) return errFail;
    }
    {
        HostUIConfigEntryRef item(kSettingKeyint);
        item.MakeSlider("Keyframe Every", "seconds", keyint, 1, 10, kDefaultKeyint);
        if (!item.IsSuccess() || !settingsList->Append(&item)) return errFail;
    }
    if (format == kInputAYUV) {
        const int32_t order = GetIntSetting(values, kSettingAyuvOrder, kAyuvOrderAYUV);
        HostUIConfigEntryRef item(kSettingAyuvOrder);
        item.MakeComboBox("AYUV Byte Order", {"A Y U V", "V U Y A", "Y U V A", "U Y V A"},
                          {kAyuvOrderAYUV, kAyuvOrderVUYA, kAyuvOrderYUVA, kAyuvOrderUYVA}, order);
        if (!item.IsSuccess() || !settingsList->Append(&item)) return errFail;
    }
    {
        HostUIConfigEntryRef item("webmalpha_note");
        item.MakeLabel("Tick Export Alpha and set Alpha Mode to Straight. Log: ~/Library/Logs/WebMAlpha.log");
        if (!item.IsSuccess() || !settingsList->Append(&item)) return errFail;
    }
    return errNone;
}

// ---------------------------------------------------------------------------
// Lifecycle
// ---------------------------------------------------------------------------

namespace {

double Now() {
    return std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count();
}

int CpuCount() {
    const unsigned n = std::thread::hardware_concurrency();
    return n == 0 ? 4 : static_cast<int>(std::min(n, 64u));
}

// VP9 splits each frame into tile columns (each at least 256 px wide) that are
// encoded in parallel. More columns = more cores busy.
int TileColumnsLog2(uint32_t width) {
    int log2 = 0;
    while (log2 < 6 && (width >> (log2 + 1)) >= 256) ++log2;
    return log2;
}

}  // namespace

Vp9AlphaEncoder::Vp9AlphaEncoder(InputFormat format) : m_format(format) {}

Vp9AlphaEncoder::~Vp9AlphaEncoder() {
    StopThread();
    Log("Encoder closed: %lld frames in, %lld packets out. Time spent: converting %.1fs, encoding %.1fs, "
        "Resolve waiting on the encoder %.1fs",
        static_cast<long long>(m_framesIn), static_cast<long long>(m_packetsOut), m_convertSeconds, m_encodeSeconds,
        m_waitSeconds);
    for (AVFrame* f : m_inQueue)
        if (f) av_frame_free(&f);
    for (AVPacket* p : m_outQueue) av_packet_free(&p);
    if (m_sws) sws_freeContext(m_sws);
    if (m_ctx) avcodec_free_context(&m_ctx);
    if (m_frame444) av_frame_free(&m_frame444);
}

void Vp9AlphaEncoder::StopThread() {
    if (!m_thread.joinable()) return;
    {
        std::lock_guard<std::mutex> lock(m_mutex);
        m_stop = true;
    }
    m_cv.notify_all();
    m_thread.join();
}

StatusCode Vp9AlphaEncoder::DoInit(HostPropertyCollectionRef* props) {
    Log("Encoder init (%s)", kFormats[m_format].name);
    DumpProps("codec init props", props);
    return errNone;
}

StatusCode Vp9AlphaEncoder::DoOpen(HostBufferRef* buf) {
    Log("Encoder open (%s)", kFormats[m_format].name);
    DumpProps("codec open props", buf);

    HostCodecConfigCommon common;
    common.Load(buf);

    m_width = common.GetWidth();
    m_height = common.GetHeight();
    uint32_t fpsNum = common.GetFrameRateNum();
    uint32_t fpsDen = common.GetFrameRateDen();
    if (fpsNum == 0 || fpsDen == 0) {
        double fps = 0;
        if (buf->GetDouble(pIOPropFrameRate, fps) && fps > 0) {
            fpsNum = static_cast<uint32_t>(fps * 1000 + 0.5);
            fpsDen = 1000;
        } else {
            fpsNum = 25;
            fpsDen = 1;
        }
    }

    if (m_width == 0 || m_height == 0) {
        Log("ERROR: Resolve did not provide width/height");
        return errNoParam;
    }

    Log("Resolve reports hasAlpha=%d (1 = Export Alpha is on). Container='%s' Path='%s'", common.HasAlpha() ? 1 : 0,
        common.GetContainer().c_str(), common.GetPath().c_str());
    if (!common.HasAlpha()) {
        Log("WARNING: Export Alpha appears to be off. The video will encode, but the alpha will be fully opaque "
            "unless Resolve still sends real alpha (see the byte analysis below).");
    }

    m_useFraming = IsOurContainer(common.GetContainer());
    Log("Packet framing for WebM alpha container: %s", m_useFraming ? "ON" : "OFF (unknown container, colour only)");

    int16_t matrix = 1, primaries = 1, transfer = 1;
    buf->GetINT16(pIOColorMatrix, matrix);
    buf->GetINT16(pIOPropColorPrimaries, primaries);
    buf->GetINT16(pIOTransferCharacteristics, transfer);
    uint8_t dataRange = 0;
    buf->GetUINT8(pIOPropDataRange, dataRange);
    const bool fullRange = dataRange == 1;

    const int32_t mode = GetIntSetting(buf, kSettingMode, kDefaultMode) == kModeQuality ? kModeQuality : kModeFast;
    const int32_t crf = std::clamp(GetIntSetting(buf, kSettingCrf, kDefaultCrf), 0, 63);
    const int32_t speed = std::clamp(GetIntSetting(buf, kSettingSpeed, kDefaultSpeed), 0, 5);
    const int32_t keyint = std::clamp(GetIntSetting(buf, kSettingKeyint, kDefaultKeyint), 1, 10);
    m_ayuvOrder = GetIntSetting(buf, kSettingAyuvOrder, kAyuvOrderAYUV);

    const AVCodec* codec = avcodec_find_encoder_by_name("libvpx-vp9");
    if (!codec) {
        Log("ERROR: this FFmpeg build has no libvpx-vp9 encoder");
        const char* msg = "WebM Alpha: FFmpeg was built without libvpx (VP9).";
        buf->SetProperty(pIOCustomErrorString, propTypeString, msg, static_cast<int>(strlen(msg)));
        return errNoCodec;
    }

    m_ctx = avcodec_alloc_context3(codec);
    if (!m_ctx) return errAlloc;

    const int cpus = CpuCount();
    const int tiles = TileColumnsLog2(m_width);

    m_ctx->width = static_cast<int>(m_width);
    m_ctx->height = static_cast<int>(m_height);
    m_ctx->pix_fmt = AV_PIX_FMT_YUVA420P;  // tells libvpx-vp9 to encode the alpha plane too
    m_ctx->time_base = AVRational{static_cast<int>(fpsDen), static_cast<int>(fpsNum)};
    m_ctx->framerate = AVRational{static_cast<int>(fpsNum), static_cast<int>(fpsDen)};
    m_ctx->gop_size = static_cast<int>((static_cast<double>(fpsNum) / fpsDen) * keyint + 0.5);
    m_ctx->bit_rate = 0;  // constant-quality mode
    m_ctx->thread_count = cpus;
    m_ctx->colorspace = static_cast<AVColorSpace>(matrix);
    m_ctx->color_primaries = static_cast<AVColorPrimaries>(primaries);
    m_ctx->color_trc = static_cast<AVColorTransferCharacteristic>(transfer);
    m_ctx->color_range = fullRange ? AVCOL_RANGE_JPEG : AVCOL_RANGE_MPEG;

    av_opt_set_int(m_ctx->priv_data, "crf", crf, 0);
    av_opt_set_int(m_ctx->priv_data, "row-mt", 1, 0);
    av_opt_set_int(m_ctx->priv_data, "tile-columns", tiles, 0);
    if (mode == kModeFast) {
        av_opt_set(m_ctx->priv_data, "deadline", "realtime", 0);
        av_opt_set_int(m_ctx->priv_data, "cpu-used", 8, 0);
    } else {
        av_opt_set(m_ctx->priv_data, "deadline", "good", 0);
        av_opt_set_int(m_ctx->priv_data, "cpu-used", speed, 0);
    }

    int ret = avcodec_open2(m_ctx, codec, nullptr);
    if (ret < 0) {
        Log("ERROR: could not open libvpx-vp9: %s", ErrStr(ret).c_str());
        return errFail;
    }

    // Colour conversion, spread across all cores.
    const int dstCs = SwsColorspaceFromMatrix(matrix);
    const AVPixelFormat srcFmt = m_format == kInputRGBA ? AV_PIX_FMT_RGBA : AV_PIX_FMT_YUVA444P;
    m_sws = sws_alloc_context();
    if (!m_sws) return errAlloc;
    av_opt_set_int(m_sws, "srcw", m_ctx->width, 0);
    av_opt_set_int(m_sws, "srch", m_ctx->height, 0);
    av_opt_set_int(m_sws, "src_format", srcFmt, 0);
    av_opt_set_int(m_sws, "dstw", m_ctx->width, 0);
    av_opt_set_int(m_sws, "dsth", m_ctx->height, 0);
    av_opt_set_int(m_sws, "dst_format", AV_PIX_FMT_YUVA420P, 0);
    av_opt_set_int(m_sws, "sws_flags", SWS_BICUBIC | SWS_ACCURATE_RND, 0);
    av_opt_set_int(m_sws, "threads", cpus, 0);
    if (sws_init_context(m_sws, nullptr, nullptr) < 0) {
        Log("ERROR: could not set up colour conversion");
        return errFail;
    }
    const int srcRange = m_format == kInputRGBA ? 1 : (fullRange ? 1 : 0);
    sws_setColorspaceDetails(m_sws, sws_getCoefficients(dstCs), srcRange, sws_getCoefficients(dstCs),
                             fullRange ? 1 : 0, 0, 1 << 16, 1 << 16);

    if (m_format == kInputAYUV) {
        m_frame444 = av_frame_alloc();
        if (!m_frame444) return errAlloc;
        m_frame444->format = AV_PIX_FMT_YUVA444P;
        m_frame444->width = m_ctx->width;
        m_frame444->height = m_ctx->height;
        if (av_frame_get_buffer(m_frame444, 32) < 0) return errAlloc;
    }

    const uint32_t temporal = 0;
    buf->SetProperty(pIOPropTemporalReordering, propTypeUInt32, &temporal, 1);
    const uint8_t multiPass = 0;
    buf->SetProperty(pIOPropMultiPass, propTypeUInt8, &multiPass, 1);

    m_thread = std::thread(&Vp9AlphaEncoder::EncoderThread, this);

    Log("libvpx-vp9 open: %ux%u @ %u/%u fps, mode %s, crf %d%s, keyframe every %d frames, %d threads, %d tile "
        "columns, %s range, matrix %d",
        m_width, m_height, fpsNum, fpsDen, mode == kModeFast ? "Fast (realtime)" : "Quality (good)", crf,
        mode == kModeFast ? "" : (", speed " + std::to_string(speed)).c_str(), m_ctx->gop_size, cpus, 1 << tiles,
        fullRange ? "full" : "video", matrix);
    return errNone;
}

// ---------------------------------------------------------------------------
// Resolve's thread: convert, queue, hand back finished packets
// ---------------------------------------------------------------------------

uint32_t Vp9AlphaEncoder::ReadStride(HostBufferRef* buf) const {
    for (const char* id : {pIOBufferStride, pIOPropStride}) {
        PropertyType type = propTypeNull;
        const void* value = nullptr;
        int count = 0;
        if (buf->GetProperty(id, &type, &value, &count) == errNone && value && count > 0) {
            if (type == propTypeUInt32) return static_cast<const uint32_t*>(value)[0];
            if (type == propTypeInt32) return static_cast<uint32_t>(static_cast<const int32_t*>(value)[0]);
        }
    }
    return m_width * 4;  // tightly packed, 4 bytes per pixel
}

AVFrame* Vp9AlphaEncoder::ConvertInput(const uint8_t* src, size_t size, uint32_t stride) {
    if (static_cast<size_t>(stride) * (m_height - 1) + static_cast<size_t>(m_width) * 4 > size) {
        Log("ERROR: frame buffer too small: %zu bytes for %ux%u stride %u", size, m_width, m_height, stride);
        return nullptr;
    }

    AVFrame* in = av_frame_alloc();
    AVFrame* out = av_frame_alloc();
    if (!in || !out) {
        av_frame_free(&in);
        av_frame_free(&out);
        return nullptr;
    }
    out->format = AV_PIX_FMT_YUVA420P;
    out->width = static_cast<int>(m_width);
    out->height = static_cast<int>(m_height);
    if (av_frame_get_buffer(out, 32) < 0) {
        av_frame_free(&in);
        av_frame_free(&out);
        return nullptr;
    }

    if (m_format == kInputRGBA) {
        in->format = AV_PIX_FMT_RGBA;
        in->width = static_cast<int>(m_width);
        in->height = static_cast<int>(m_height);
        in->data[0] = const_cast<uint8_t*>(src);
        in->linesize[0] = static_cast<int>(stride);
    } else {
        // AYUV: split the interleaved bytes into Y, U, V, A planes first.
        int iA = 0, iY = 1, iU = 2, iV = 3;
        switch (m_ayuvOrder) {
            case kAyuvOrderVUYA: iV = 0; iU = 1; iY = 2; iA = 3; break;
            case kAyuvOrderYUVA: iY = 0; iU = 1; iV = 2; iA = 3; break;
            case kAyuvOrderUYVA: iU = 0; iY = 1; iV = 2; iA = 3; break;
            default: break;
        }
        for (uint32_t y = 0; y < m_height; ++y) {
            const uint8_t* row = src + static_cast<size_t>(y) * stride;
            uint8_t* pY = m_frame444->data[0] + static_cast<size_t>(y) * m_frame444->linesize[0];
            uint8_t* pU = m_frame444->data[1] + static_cast<size_t>(y) * m_frame444->linesize[1];
            uint8_t* pV = m_frame444->data[2] + static_cast<size_t>(y) * m_frame444->linesize[2];
            uint8_t* pA = m_frame444->data[3] + static_cast<size_t>(y) * m_frame444->linesize[3];
            for (uint32_t x = 0; x < m_width; ++x) {
                const uint8_t* px = row + x * 4;
                pY[x] = px[iY];
                pU[x] = px[iU];
                pV[x] = px[iV];
                pA[x] = px[iA];
            }
        }
        av_frame_ref(in, m_frame444);
    }

    const int ret = sws_scale_frame(m_sws, out, in);
    av_frame_free(&in);
    if (ret < 0) {
        Log("ERROR: colour conversion failed: %s", ErrStr(ret).c_str());
        av_frame_free(&out);
        return nullptr;
    }
    return out;
}

StatusCode Vp9AlphaEncoder::DoProcess(HostBufferRef* buf) {
    if (!m_ctx) return errInvalidOperation;

    // ---- end of render: drain the encoder ----
    if (buf == nullptr || !buf->IsValid()) {
        if (m_flushed) return errNone;
        m_flushed = true;
        Log("Flushing encoder");
        const double t0 = Now();
        {
            std::unique_lock<std::mutex> lock(m_mutex);
            m_inQueue.push_back(nullptr);
            m_cv.notify_all();
            m_cv.wait(lock, [&] { return m_encoderDone; });
        }
        m_waitSeconds += Now() - t0;
        if (m_thread.joinable()) m_thread.join();
        const StatusCode err = SendReadyPackets();
        if (m_encoderFailed) return errFail;
        return err;
    }

    // ---- a frame from Resolve ----
    char* data = nullptr;
    size_t size = 0;
    if (!buf->LockBuffer(&data, &size) || data == nullptr || size == 0) {
        Log("ERROR: could not lock input frame");
        return errFail;
    }

    const uint32_t stride = ReadStride(buf);
    int64_t pts = m_framesIn;
    if (!buf->GetINT64(pIOPropPTS, pts)) pts = m_framesIn;

    if (!m_firstFrameLogged) {
        m_firstFrameLogged = true;
        DumpProps("first frame props", buf);
        AnalyseInterleaved4(m_format == kInputRGBA ? "first frame (expect byte[3] = alpha)"
                                                   : "first frame (AYUV; alpha byte varies with the matte)",
                            reinterpret_cast<const uint8_t*>(data), size, m_width, m_height, stride);
    }

    double t0 = Now();
    AVFrame* frame = ConvertInput(reinterpret_cast<const uint8_t*>(data), size, stride);
    buf->UnlockBuffer();
    m_convertSeconds += Now() - t0;
    if (!frame) return errFail;
    frame->pts = pts;

    // Queue it for the encoder thread. Only wait if the encoder is a few frames
    // behind (keeps memory bounded: a 4K frame is ~20 MB).
    t0 = Now();
    {
        std::unique_lock<std::mutex> lock(m_mutex);
        m_cv.wait(lock, [&] { return m_inQueue.size() < kMaxQueuedFrames || m_encoderDone; });
        if (m_encoderFailed || m_encoderDone) {
            av_frame_free(&frame);
            Log("ERROR: encoder thread stopped unexpectedly");
            return errFail;
        }
        m_inQueue.push_back(frame);
    }
    m_cv.notify_all();
    m_waitSeconds += Now() - t0;
    ++m_framesIn;

    const StatusCode err = SendReadyPackets();
    if (err != errNone) return err;
    return errMoreData;
}

StatusCode Vp9AlphaEncoder::SendReadyPackets() {
    std::deque<AVPacket*> ready;
    {
        std::lock_guard<std::mutex> lock(m_mutex);
        ready.swap(m_outQueue);
    }
    StatusCode result = errNone;
    for (AVPacket* pkt : ready) {
        if (result == errNone) result = SendPacket(pkt);
        av_packet_free(&pkt);
    }
    return result;
}

// ---------------------------------------------------------------------------
// Encoder thread
// ---------------------------------------------------------------------------

void Vp9AlphaEncoder::EncoderThread() {
    AVPacket* pkt = av_packet_alloc();
    bool failed = pkt == nullptr;

    while (!failed) {
        AVFrame* frame = nullptr;
        {
            std::unique_lock<std::mutex> lock(m_mutex);
            m_cv.wait(lock, [&] { return m_stop || !m_inQueue.empty(); });
            if (m_inQueue.empty()) break;  // stopped without a flush
            frame = m_inQueue.front();
            m_inQueue.pop_front();
        }
        m_cv.notify_all();  // room in the queue

        const double t0 = Now();
        const bool isFlush = frame == nullptr;
        int ret = avcodec_send_frame(m_ctx, frame);
        if (frame) av_frame_free(&frame);
        if (ret < 0 && ret != AVERROR_EOF) {
            Log("ERROR: avcodec_send_frame: %s", ErrStr(ret).c_str());
            failed = true;
            break;
        }

        bool eof = false;
        while (true) {
            ret = avcodec_receive_packet(m_ctx, pkt);
            if (ret == AVERROR(EAGAIN)) break;
            if (ret == AVERROR_EOF) {
                eof = true;
                break;
            }
            if (ret < 0) {
                Log("ERROR: avcodec_receive_packet: %s", ErrStr(ret).c_str());
                failed = true;
                break;
            }
            AVPacket* out = av_packet_alloc();
            if (out) av_packet_move_ref(out, pkt);
            std::lock_guard<std::mutex> lock(m_mutex);
            m_outQueue.push_back(out);
        }
        m_encodeSeconds += Now() - t0;
        if (eof || isFlush) break;
    }

    av_packet_free(&pkt);
    {
        std::lock_guard<std::mutex> lock(m_mutex);
        m_encoderDone = true;
        m_encoderFailed = failed;
    }
    m_cv.notify_all();
}

// ---------------------------------------------------------------------------
// Packets back to Resolve (always on Resolve's thread)
// ---------------------------------------------------------------------------

StatusCode Vp9AlphaEncoder::SendPacket(const AVPacket* pkt) {
    if (!pkt) return errAlloc;
    size_t sideSize = 0;
    const uint8_t* side = av_packet_get_side_data(pkt, AV_PKT_DATA_MATROSKA_BLOCKADDITIONAL, &sideSize);
    if (!m_useFraming) {
        side = nullptr;
        sideSize = 0;
    }

    if (m_packetsOut == 0) {
        Log("First packet: colour %d bytes, alpha side data %zu bytes%s", pkt->size, sideSize,
            sideSize ? "" : "  <-- no alpha data from libvpx!");
    }

    const size_t total = m_useFraming ? kFrameHeaderSize + pkt->size + sideSize : static_cast<size_t>(pkt->size);
    HostBufferRef out(false);
    if (!out.IsValid() || !out.Resize(total)) return errAlloc;

    char* dst = nullptr;
    size_t dstSize = 0;
    if (!out.LockBuffer(&dst, &dstSize) || dstSize < total) return errAlloc;

    uint8_t* p = reinterpret_cast<uint8_t*>(dst);
    if (m_useFraming) {
        const uint32_t fields[6] = {static_cast<uint32_t>(pkt->size),
                                    static_cast<uint32_t>(sideSize),
                                    m_width,
                                    m_height,
                                    static_cast<uint32_t>(m_ctx->framerate.num),
                                    static_cast<uint32_t>(m_ctx->framerate.den)};
        memcpy(p, kFrameMagic, 4);
        for (int f = 0; f < 6; ++f)
            for (int i = 0; i < 4; ++i) p[4 + f * 4 + i] = static_cast<uint8_t>(fields[f] >> (8 * i));
        p += kFrameHeaderSize;
    }
    memcpy(p, pkt->data, pkt->size);
    if (sideSize) memcpy(p + pkt->size, side, sideSize);
    out.UnlockBuffer();

    const int64_t pts = pkt->pts;
    const int64_t dts = pkt->dts;
    out.SetProperty(pIOPropPTS, propTypeInt64, &pts, 1);
    out.SetProperty(pIOPropDTS, propTypeInt64, &dts, 1);
    const uint8_t key = (pkt->flags & AV_PKT_FLAG_KEY) ? 1 : 0;
    out.SetProperty(pIOPropIsKeyFrame, propTypeUInt8, &key, 1);

    ++m_packetsOut;
    return m_pCallback ? m_pCallback->SendOutput(&out) : errInvalidOperation;
}

void Vp9AlphaEncoder::DoFlush() { DoProcess(nullptr); }

}  // namespace webmalpha
