#include "diag_log.h"

#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <mutex>
#include <pwd.h>
#include <unistd.h>
#include <vector>

#include "settings.h"

namespace webmalpha {

namespace {

std::mutex g_mutex;

const char* TypeName(PropertyType t) {
    switch (t) {
        case propTypeNull: return "null";
        case propTypeInt8: return "int8";
        case propTypeUInt8: return "uint8";
        case propTypeInt16: return "int16";
        case propTypeUInt16: return "uint16";
        case propTypeInt32: return "int32";
        case propTypeUInt32: return "uint32";
        case propTypeInt64: return "int64";
        case propTypeUInt64: return "uint64";
        case propTypeDouble: return "double";
        case propTypeString: return "string";
    }
    return "?";
}

std::string FormatValue(PropertyType type, const void* value, int count) {
    if (value == nullptr || count <= 0) return "(empty)";
    std::string out;
    char tmp[64];

    if (type == propTypeString) {
        // String lists are NUL-separated; show separators as " | ".
        const char* s = static_cast<const char*>(value);
        out.push_back('"');
        for (int i = 0; i < count; ++i) {
            if (s[i] == '\0') {
                if (i != count - 1) out += "\" | \"";
            } else {
                out.push_back(s[i]);
            }
        }
        out.push_back('"');
        return out;
    }

    const int shown = count > 32 ? 32 : count;
    for (int i = 0; i < shown; ++i) {
        switch (type) {
            case propTypeInt8: snprintf(tmp, sizeof(tmp), "%d", static_cast<const int8_t*>(value)[i]); break;
            case propTypeUInt8: snprintf(tmp, sizeof(tmp), "%u", static_cast<const uint8_t*>(value)[i]); break;
            case propTypeInt16: snprintf(tmp, sizeof(tmp), "%d", static_cast<const int16_t*>(value)[i]); break;
            case propTypeUInt16: snprintf(tmp, sizeof(tmp), "%u", static_cast<const uint16_t*>(value)[i]); break;
            case propTypeInt32: snprintf(tmp, sizeof(tmp), "%d", static_cast<const int32_t*>(value)[i]); break;
            case propTypeUInt32: snprintf(tmp, sizeof(tmp), "%u", static_cast<const uint32_t*>(value)[i]); break;
            case propTypeInt64:
                snprintf(tmp, sizeof(tmp), "%lld", static_cast<long long>(static_cast<const int64_t*>(value)[i]));
                break;
            case propTypeUInt64:
                snprintf(tmp, sizeof(tmp), "%llu",
                         static_cast<unsigned long long>(static_cast<const uint64_t*>(value)[i]));
                break;
            case propTypeDouble: snprintf(tmp, sizeof(tmp), "%g", static_cast<const double*>(value)[i]); break;
            default: snprintf(tmp, sizeof(tmp), "?"); break;
        }
        if (i) out += ", ";
        out += tmp;
    }
    if (shown < count) out += ", ...";
    return out;
}

}  // namespace

std::vector<std::string> LogFilePaths() {
    std::vector<std::string> out;
    auto add = [&](const std::string& path) {
        if (path.empty()) return;
        for (const auto& p : out)
            if (p == path) return;
        out.push_back(path);
    };
    if (const char* override_path = getenv("WEBM_ALPHA_LOG")) add(override_path);
#if defined(__APPLE__)
    // HOME is the sandbox container for the App Store build of Resolve, and the
    // real home folder otherwise. Try both.
    if (const char* home = getenv("HOME")) add(std::string(home) + "/Library/Logs/WebMAlpha.log");
    if (const passwd* pw = getpwuid(getuid())) add(std::string(pw->pw_dir) + "/Library/Logs/WebMAlpha.log");
    add("/tmp/WebMAlpha.log");
#else
    const char* tmp = getenv("TMPDIR");
    std::string dir = (tmp && *tmp) ? tmp : "/tmp";
    if (!dir.empty() && dir.back() == '/') dir.pop_back();
    add(dir + "/WebMAlpha.log");
#endif
    return out;
}

std::string LogFilePath() { return LogFilePaths().front(); }

void Log(const char* fmt, ...) {
    char msg[4096];
    va_list args;
    va_start(args, fmt);
    vsnprintf(msg, sizeof(msg), fmt, args);
    va_end(args);

    std::lock_guard<std::mutex> lock(g_mutex);

    char stamp[32];
    time_t now = time(nullptr);
    strftime(stamp, sizeof(stamp), "%Y-%m-%d %H:%M:%S", localtime(&now));

    bool wrote = false;
    for (const auto& path : LogFilePaths()) {
        if (FILE* f = fopen(path.c_str(), "a")) {
            fprintf(f, "[%s] %s\n", stamp, msg);
            fclose(f);
            wrote = true;
            if (getenv("WEBM_ALPHA_LOG")) break;  // tests: one file is enough
        }
    }
    if (!wrote) fprintf(stderr, "WebM Alpha :: %s\n", msg);

    g_Log(logLevelInfo, "WebM Alpha :: %s", msg);
}

void DumpProps(const char* title, IPropertyProvider* props) {
    if (props == nullptr) {
        Log("%s: (no properties)", title);
        return;
    }

    // The SDK has no way to enumerate a property bag, so ask for every ID we
    // know about and print whatever Resolve actually set.
    static const char* const kIds[] = {
        pIOPropUUID, pIOPropFourCC, pIOPropName, pIOPropGroup, pIOPropPath, pIOPropContainerList,
        pIOPropContainerExt, pIOPropMediaType, pIOPropCodecDirection, pIOPropWidth, pIOPropHeight,
        pIOPropStride, pIOBufferStride, pIOPropFieldOrder, pIOPropFrameRate, pIOPropFrameRateIsDrop,
        pIOPropTimeBase, pIOPropBitDepth, pIOPropBitsPerSample, pIOPropColorModel, pIOPropHSubsampling,
        pIOPropVSubsampling, pIOPropHasAlpha, pIOPropDataRange, pIOColorMatrix, pIOPropColorPrimaries,
        pIOTransferCharacteristics, pIOPropPTS, pIOPropDTS, pIOPropDuration, pIOPropIsKeyFrame,
        pIOPropTrackIdx, pIOPropPAR, pIOPropMagicCookieType, pIOPropTemporalReordering,
        pIOPropNumChannels, pIOPropSamplingRate, pIOPropAudioChannelLayout, pIOPropIsFloat,
        pIOPropByteOrder, pIOPropStartTime, pIOPropBitRate, pIOPropMultiPass,
        // Our own UI settings
        kSettingCrf, kSettingSpeed, kSettingKeyint, kSettingAyuvOrder, kSettingMode,
    };

    Log("---- %s ----", title);
    for (const char* id : kIds) {
        PropertyType type = propTypeNull;
        const void* value = nullptr;
        int count = 0;
        if (props->GetProperty(id, &type, &value, &count) == errNone && type != propTypeNull) {
            Log("  %-18s %-7s [%d] %s", id, TypeName(type), count, FormatValue(type, value, count).c_str());
        }
    }
}

void AnalyseInterleaved4(const char* title, const uint8_t* data, size_t size, uint32_t width, uint32_t height,
                         uint32_t stride) {
    if (data == nullptr || width == 0 || height == 0) return;
    if (stride == 0) stride = width * 4;

    uint8_t mn[4] = {255, 255, 255, 255};
    uint8_t mx[4] = {0, 0, 0, 0};
    uint64_t sum[4] = {0, 0, 0, 0};
    uint64_t n = 0;

    for (uint32_t y = 0; y < height; ++y) {
        const size_t rowStart = static_cast<size_t>(y) * stride;
        if (rowStart + static_cast<size_t>(width) * 4 > size) break;
        const uint8_t* row = data + rowStart;
        for (uint32_t x = 0; x < width; ++x) {
            for (int c = 0; c < 4; ++c) {
                const uint8_t v = row[x * 4 + c];
                if (v < mn[c]) mn[c] = v;
                if (v > mx[c]) mx[c] = v;
                sum[c] += v;
            }
            ++n;
        }
    }

    Log("---- %s: byte analysis over %llu pixels (buffer %zu bytes, %ux%u, stride %u) ----", title,
        static_cast<unsigned long long>(n), size, width, height, stride);
    for (int c = 0; c < 4; ++c) {
        Log("  byte[%d]  min %3u  max %3u  mean %6.1f", c, mn[c], mx[c], n ? static_cast<double>(sum[c]) / n : 0.0);
    }
}

}  // namespace webmalpha
