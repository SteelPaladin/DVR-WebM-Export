#pragma once

#include <cstdint>

namespace webmalpha {

// ---------------------------------------------------------------------------
// Identifiers
// ---------------------------------------------------------------------------

// Plugin (bundle) UUID:          6A1E0B57-3C2D-4E8F-9A61-0F5B2C7D9E01
static const uint8_t kPluginUUID[16] = {0x6A, 0x1E, 0x0B, 0x57, 0x3C, 0x2D, 0x4E, 0x8F,
                                        0x9A, 0x61, 0x0F, 0x5B, 0x2C, 0x7D, 0x9E, 0x01};

// Codec UUID base. The last byte is offset by the input-format index, so the
// RGBA variant ends ...10 and the AYUV variant ends ...11.
//                                 6A1E0B57-3C2D-4E8F-9A61-0F5B2C7D9E10
static const uint8_t kCodecUUID[16] = {0x6A, 0x1E, 0x0B, 0x57, 0x3C, 0x2D, 0x4E, 0x8F,
                                       0x9A, 0x61, 0x0F, 0x5B, 0x2C, 0x7D, 0x9E, 0x10};

// Container UUID:                6A1E0B57-3C2D-4E8F-9A61-0F5B2C7D9E20
static const uint8_t kContainerUUID[16] = {0x6A, 0x1E, 0x0B, 0x57, 0x3C, 0x2D, 0x4E, 0x8F,
                                           0x9A, 0x61, 0x0F, 0x5B, 0x2C, 0x7D, 0x9E, 0x20};

static const char* const kContainerUUIDDashed = "6A1E0B57-3C2D-4E8F-9A61-0F5B2C7D9E20";

// ---------------------------------------------------------------------------
// Input formats we ask Resolve for. Both carry an alpha channel.
// ---------------------------------------------------------------------------
enum InputFormat : uint8_t {
    kInputRGBA = 0,  // interleaved R,G,B,A 8-bit
    kInputAYUV = 1,  // interleaved YUV + alpha 4:4:4 8-bit (byte order verified by diagnostics)
    kInputFormatCount = 2,
};

// ---------------------------------------------------------------------------
// Encoder settings shown on the Deliver page (keys are stored in the preset)
// ---------------------------------------------------------------------------
static const char* const kSettingCrf = "webmalpha_crf";            // int32 0..63, lower = better
static const char* const kSettingSpeed = "webmalpha_speed";        // int32 0..8 (libvpx cpu-used)
static const char* const kSettingKeyint = "webmalpha_keyint";      // int32 seconds between keyframes
static const char* const kSettingAyuvOrder = "webmalpha_ayuvord";  // int32 AYUV byte order, see AyuvOrder
static const char* const kSettingMode = "webmalpha_mode";          // int32 EncodeMode

enum EncodeMode : int32_t {
    kModeFast = 0,     // libvpx "realtime": several times faster, somewhat larger files
    kModeQuality = 1,  // libvpx "good": smallest files, slow
};
static const int32_t kDefaultMode = kModeFast;

static const int32_t kDefaultCrf = 30;
static const int32_t kDefaultSpeed = 4;
static const int32_t kDefaultKeyint = 2;

// Byte order of the AYUV input, in case Resolve's "AYUV" isn't literally A,Y,U,V.
enum AyuvOrder : int32_t {
    kAyuvOrderAYUV = 0,  // A Y U V
    kAyuvOrderVUYA = 1,  // V U Y A (Microsoft/D3D style)
    kAyuvOrderYUVA = 2,  // Y U V A
    kAyuvOrderUYVA = 3,  // U Y V A
};

// ---------------------------------------------------------------------------
// Packet framing between our codec and our container.
//
// VP9 alpha in WebM is really two VP9 streams: colour frames in the normal
// SimpleBlock, and a separate alpha (greyscale) frame stored alongside it as a
// Matroska BlockAdditional. Resolve only carries one byte buffer per packet
// from codec to container, so the codec packs both into one buffer:
//
//   offset 0   'W' 'B' 'M' 'A'          magic
//   offset 4   uint32 LE  colourSize
//   offset 8   uint32 LE  sideDataSize  (FFmpeg BLOCKADDITIONAL side data, may be 0)
//   offset 12  uint32 LE  width         (so the container never depends on
//   offset 16  uint32 LE  height         Resolve describing the track)
//   offset 20  uint32 LE  fpsNum
//   offset 24  uint32 LE  fpsDen
//   offset 28  colour bytes
//   ...        side data bytes
//
// Only our own container understands this. If Resolve ever pairs the codec
// with some other container, the codec detects that and sends plain VP9.
// ---------------------------------------------------------------------------
static const uint8_t kFrameMagic[4] = {'W', 'B', 'M', 'A'};
static const size_t kFrameHeaderSize = 28;

}  // namespace webmalpha
