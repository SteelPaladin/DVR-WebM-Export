#pragma once

#include <cstdint>
#include <string>

#include "plugin_api.h"

extern "C" {
#include <libavformat/avformat.h>
}

namespace webmalpha {

// A WebM writer that Resolve treats as a container ("format") choice on the
// Deliver page. It receives our framed VP9 packets and writes the alpha data
// as Matroska BlockAdditionals with AlphaMode=1, which is what Chrome,
// Firefox, OBS and ffmpeg recognise as transparent VP9.
//
// Resolve's call order (init / open / add track) isn't documented, so nothing
// here depends on it: init, open and add-track only record information, and
// the file itself is created when the first video packet arrives.
class WebMContainer : public IPluginContainerRef {
   public:
    WebMContainer();

    static StatusCode RegisterContainers(HostListRef* list);

    // Called by the video track
    StatusCode WriteVideo(HostBufferRef* buf);

   protected:
    ~WebMContainer();

    StatusCode DoInit(HostPropertyCollectionRef* props) override;
    StatusCode DoOpen(HostPropertyCollectionRef* props) override;
    StatusCode DoAddTrack(HostPropertyCollectionRef* props, HostPropertyCollectionRef* codecProps,
                          IPluginTrackBase** track) override;
    StatusCode DoClose() override;

   private:
    void TakePath(IPropertyProvider* props, const char* where);
    StatusCode EnsureMuxer();

    std::string m_path;

    // What we know about the video track (from Resolve and/or the packets)
    bool m_haveVideoTrack = false;
    uint32_t m_width = 0;
    uint32_t m_height = 0;
    AVRational m_fps{0, 1};
    int m_colorSpace = AVCOL_SPC_UNSPECIFIED;
    int m_colorPrimaries = AVCOL_PRI_UNSPECIFIED;
    int m_colorTrc = AVCOL_TRC_UNSPECIFIED;
    int m_colorRange = AVCOL_RANGE_UNSPECIFIED;

    AVFormatContext* m_fmt = nullptr;
    AVStream* m_video = nullptr;
    AVRational m_codecTimeBase{1, 25};
    bool m_closed = false;
    bool m_failed = false;
    int64_t m_packets = 0;
    int64_t m_alphaPackets = 0;
    int64_t m_lastDts = INT64_MIN;
};

class WebMVideoTrack : public IPluginTrackBase, public IPluginTrackWriter {
   public:
    explicit WebMVideoTrack(WebMContainer* container) : IPluginTrackBase(container), m_owner(container) {}
    StatusCode DoWrite(HostBufferRef* buf) override;

   protected:
    ~WebMVideoTrack() override = default;

   private:
    WebMContainer* m_owner;
};

// WebM can only hold Opus/Vorbis audio; this version is video-only, so audio
// handed to us is accepted and discarded (and logged) rather than failing.
class WebMDiscardTrack : public IPluginTrackBase, public IPluginTrackWriter {
   public:
    explicit WebMDiscardTrack(WebMContainer* container) : IPluginTrackBase(container) {}
    StatusCode DoWrite(HostBufferRef* buf) override;

   protected:
    ~WebMDiscardTrack() override = default;

   private:
    int64_t m_dropped = 0;
};

}  // namespace webmalpha
