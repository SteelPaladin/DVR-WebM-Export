// WebM Alpha: an encoder + container plugin for DaVinci Resolve Studio that
// renders transparent VP9 WebM directly from the Deliver page.

#include <cstring>

#include "diag_log.h"
#include "plugin_api.h"
#include "settings.h"
#include "vp9_alpha_encoder.h"
#include "webm_container.h"

extern "C" {
#include <libavcodec/avcodec.h>
#include <libavformat/avformat.h>
#include <libswscale/swscale.h>
}

using namespace webmalpha;

extern void (*g_pTraceHook)(unsigned int p_MsgID, int p_Result);

namespace {

const char* MessageName(unsigned int id) {
    switch (id) {
        case msgCreate: return "create";
        case msgRetain: return "retain";
        case msgRelease: return "release";
        case msgCodecSettings: return "codecSettings";
        case msgPluginStart: return "pluginStart";
        case msgPluginTerminate: return "pluginTerminate";
        case msgPluginListCodecs: return "listCodecs";
        case msgPluginListContainers: return "listContainers";
        case msgPluginGetInfo: return "getInfo";
        case msgCodecInit: return "codecInit";
        case msgCodecOpen: return "codecOpen";
        case msgCodecFlush: return "codecFlush";
        case msgCodecSetCallback: return "codecSetCallback";
        case msgCodecProcessData: return "codecProcessData";
        case msgCodecAcceptFramePTS: return "codecAcceptFramePTS";
        case msgCodecNeedNextPass: return "codecNeedNextPass";
        case msgContainerInit: return "containerInit";
        case msgContainerOpen: return "containerOpen";
        case msgContainerAddTrack: return "containerAddTrack";
        case msgContainerClose: return "containerClose";
        case msgTrackWrite: return "trackWrite";
        default: return nullptr;
    }
}

// Records every call Resolve makes into the plugin, so a failed render shows
// exactly which step Resolve was on. Per-frame calls are logged a few times only.
void TraceMessage(unsigned int id, int result) {
    if (id == msgRetain || id == msgRelease) return;
    static int processCount = 0, writeCount = 0;
    if (id == msgCodecProcessData && ++processCount > 3 && result >= 0) return;
    if (id == msgTrackWrite && ++writeCount > 3 && result >= 0) return;
    const char* name = MessageName(id);
    if (name)
        Log("call %-20s -> %d%s", name, result, result < 0 ? "  <-- FAILED" : "");
    else
        Log("call 0x%08X (unknown to this plugin) -> %d", id, result);
}

// Runs the moment macOS loads the library, before Resolve calls anything.
__attribute__((constructor)) void OnLibraryLoad() {
    Log("==== WebM Alpha v0.4 library loaded into the host process ====");
    g_pTraceHook = TraceMessage;
}

bool MatchCodec(const unsigned char* uuid, InputFormat& format) {
    if (memcmp(uuid, kCodecUUID, 15) != 0) return false;
    const int idx = uuid[15] - kCodecUUID[15];
    if (idx < 0 || idx >= kInputFormatCount) return false;
    format = static_cast<InputFormat>(idx);
    return true;
}

}  // namespace

StatusCode g_HandleGetInfo(HostPropertyCollectionRef* props) {
    StatusCode err = props->SetProperty(pIOPropUUID, propTypeUInt8, kPluginUUID, 16);
    if (err == errNone) {
        const char* name = "WebM Alpha";
        err = props->SetProperty(pIOPropName, propTypeString, name, static_cast<int>(strlen(name)));
    }
    return err;
}

StatusCode g_HandleCreateObj(unsigned char* uuid, ObjectRef* obj) {
    InputFormat format;
    if (MatchCodec(uuid, format)) {
        *obj = new Vp9AlphaEncoder(format);
        return errNone;
    }
    if (memcmp(uuid, kContainerUUID, 16) == 0) {
        *obj = new WebMContainer();
        return errNone;
    }
    Log("Resolve asked for an unknown object %02X%02X%02X%02X-...-%02X%02X", uuid[0], uuid[1], uuid[2], uuid[3],
        uuid[14], uuid[15]);
    return errUnsupported;
}

StatusCode g_HandlePluginStart() {
    Log("==== WebM Alpha plugin v0.4 started by Resolve (libavcodec %u.%u, libavformat %u.%u, libswscale %u.%u) ====",
        LIBAVCODEC_VERSION_MAJOR, LIBAVCODEC_VERSION_MINOR, LIBAVFORMAT_VERSION_MAJOR, LIBAVFORMAT_VERSION_MINOR,
        LIBSWSCALE_VERSION_MAJOR, LIBSWSCALE_VERSION_MINOR);
    if (!avcodec_find_encoder_by_name("libvpx-vp9")) {
        Log("WARNING: libvpx-vp9 is missing from this FFmpeg build; encoding will fail");
    }
    return errNone;
}

StatusCode g_HandlePluginTerminate() { return errNone; }

StatusCode g_ListCodecs(HostListRef* list) { return Vp9AlphaEncoder::RegisterCodecs(list); }

StatusCode g_ListContainers(HostListRef* list) { return WebMContainer::RegisterContainers(list); }

StatusCode g_GetEncoderSettings(unsigned char* uuid, HostPropertyCollectionRef* values, HostListRef* settingsList) {
    InputFormat format;
    if (!MatchCodec(uuid, format)) return errNoCodec;
    return Vp9AlphaEncoder::GetEncoderSettings(format, values, settingsList);
}
