#pragma once

#include <condition_variable>
#include <cstdint>
#include <deque>
#include <mutex>
#include <string>
#include <thread>

#include "plugin_api.h"
#include "settings.h"

extern "C" {
#include <libavcodec/avcodec.h>
#include <libswscale/swscale.h>
}

namespace webmalpha {

// Pipeline (v0.4):
//
//   Resolve's thread                         encoder thread
//   ----------------                         --------------
//   DoProcess(frame)
//     convert RGBA -> YUVA 4:2:0  (all cores)
//     queue the frame  ───────────────────►  libvpx encodes colour + alpha
//     hand finished packets back  ◄────────  finished packets
//   return (Resolve renders the next frame while we encode this one)
//
// Packets are only ever handed to Resolve from Resolve's own thread.
class Vp9AlphaEncoder : public IPluginCodecRef {
   public:
    explicit Vp9AlphaEncoder(InputFormat format);

    static StatusCode RegisterCodecs(HostListRef* list);
    static StatusCode GetEncoderSettings(InputFormat format, HostPropertyCollectionRef* values,
                                         HostListRef* settingsList);

   protected:
    ~Vp9AlphaEncoder() override;

    StatusCode DoInit(HostPropertyCollectionRef* props) override;
    StatusCode DoOpen(HostBufferRef* buf) override;
    StatusCode DoProcess(HostBufferRef* buf) override;
    void DoFlush() override;

   private:
    AVFrame* ConvertInput(const uint8_t* src, size_t size, uint32_t stride);
    StatusCode SendReadyPackets();
    StatusCode SendPacket(const AVPacket* pkt);
    uint32_t ReadStride(HostBufferRef* buf) const;
    void EncoderThread();
    void StopThread();

    InputFormat m_format;
    bool m_useFraming = true;  // true when paired with our own WebM container
    bool m_firstFrameLogged = false;
    bool m_flushed = false;
    int32_t m_ayuvOrder = kAyuvOrderAYUV;
    uint32_t m_width = 0;
    uint32_t m_height = 0;
    int64_t m_framesIn = 0;
    int64_t m_packetsOut = 0;

    AVCodecContext* m_ctx = nullptr;
    AVFrame* m_frame444 = nullptr;  // yuva444p staging for AYUV input
    SwsContext* m_sws = nullptr;

    // Encoder thread hand-off
    std::thread m_thread;
    std::mutex m_mutex;
    std::condition_variable m_cv;
    std::deque<AVFrame*> m_inQueue;     // nullptr entry = flush
    std::deque<AVPacket*> m_outQueue;
    bool m_encoderDone = false;         // thread finished (flushed or failed)
    bool m_encoderFailed = false;
    bool m_stop = false;
    static const size_t kMaxQueuedFrames = 3;

    // Timing, for the log
    double m_convertSeconds = 0;
    double m_waitSeconds = 0;
    double m_encodeSeconds = 0;
};

}  // namespace webmalpha
