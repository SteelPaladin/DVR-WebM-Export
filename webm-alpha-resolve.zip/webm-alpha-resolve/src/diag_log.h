#pragma once

// Diagnostic logging for the WebM Alpha plugin.
//
// Everything goes to two places:
//   1. Resolve's own log (via g_Log), and
//   2. A plain text file you can open directly:
//        macOS:  ~/Library/Logs/WebMAlpha.log
//        other:  $TMPDIR/WebMAlpha.log (or /tmp/WebMAlpha.log)
//
// The file is the important one for testing: it records every property
// Resolve hands the plugin, plus a per-byte analysis of the first frame so we
// can see exactly where (and whether) Resolve puts the alpha channel.

#include <cstdarg>
#include <cstdint>
#include <cstddef>
#include <string>
#include <vector>

#include "host_api.h"

namespace webmalpha {

void Log(const char* fmt, ...);

// Dump every property we know about from a property bag / buffer.
void DumpProps(const char* title, IPropertyProvider* props);

// Analyse an interleaved 4-byte-per-pixel frame: per byte position, report
// min / max / mean. Whichever position varies like a matte (and is 255 on an
// opaque clip) is the alpha channel.
void AnalyseInterleaved4(const char* title, const uint8_t* data, size_t size, uint32_t width, uint32_t height,
                         uint32_t stride);

std::string LogFilePath();
std::vector<std::string> LogFilePaths();

}  // namespace webmalpha
