#include "webm_container.h"

#include <cstring>
#include <string>

#include "diag_log.h"
#include "settings.h"

extern "C" {
#include <libavutil/dict.h>
#include <libavutil/mathematics.h>
#include <libavutil/pixfmt.h>
}

namespace webmalpha {

namespace {

std::string ErrStr(int err) {
    char buf[AV_ERROR_MAX_STRING_SIZE] = {0};
    av_strerror(err, buf, sizeof(buf));
    return buf;
}

uint32_t ReadLE32(const uint8_t* p) {
    return static_cast<uint32_t>(p[0]) | (static_cast<uint32_t>(p[1]) << 8) | (static_cast<uint32_t>(p[2]) << 16) |
           (static_cast<uint32_t>(p[3]) << 24);
}

// Look for a property in the track props first, then the codec props.
template <typename F>
bool FromEither(HostPropertyCollectionRef* a, HostPropertyCollectionRef* b, F get) {
    if (a && a->IsValid() && get(a)) return true;
    if (b && b->IsValid() && get(b)) return true;
    return false;
}

bool ReadFrameRate(IPropertyProvider* p, AVRational& out) {
    PropertyType type = propTypeNull;
    const void* value = nullptr;
    int count = 0;
    if (p->GetProperty(pIOPropFrameRate, &type, &value, &count) != errNone || !value) return false;
    if (type == propTypeUInt32 && count == 2) {
        const uint32_t* v = static_cast<const uint32_t*>(value);
        if (v[0] && v[1]) {
            out = AVRational{static_cast<int>(v[0]), static_cast<int>(v[1])};
            return true;
        }
    }
    if (type == propTypeDouble && count == 1) {
        const double fps = *static_cast<const double*>(value);
        if (fps > 0) {
            out = av_d2q(fps, 100000);
            return true;
        }
    }
    return false;
}

}  // namespace

// ---------------------------------------------------------------------------
// Registration
// ---------------------------------------------------------------------------

StatusCode WebMContainer::RegisterContainers(HostListRef* list) {
    HostPropertyCollectionRef info;
    if (!info.IsValid()) return errAlloc;

    info.SetProperty(pIOPropUUID, propTypeUInt8, kContainerUUID, 16);

    const char* name = "WebM";
    info.SetProperty(pIOPropName, propTypeString, name, static_cast<int>(strlen(name)));

    const char* ext = "webm";
    info.SetProperty(pIOPropContainerExt, propTypeString, ext, static_cast<int>(strlen(ext)));

    const uint32_t media = mediaVideo | mediaAudio;
    info.SetProperty(pIOPropMediaType, propTypeUInt32, &media, 1);

    if (!list->Append(&info)) return errFail;
    Log("Registered container 'WebM' (.webm)");
    return errNone;
}

// ---------------------------------------------------------------------------
// Lifecycle
// ---------------------------------------------------------------------------

WebMContainer::WebMContainer() { Log("Container created"); }

WebMContainer::~WebMContainer() {
    if (!m_closed) DoClose();
}

void WebMContainer::TakePath(IPropertyProvider* props, const char* where) {
    if (!props) return;
    std::string path;
    if (props->GetString(pIOPropPath, path) && !path.empty() && path != m_path) {
        m_path = path;
        Log("Output path (from %s): %s", where, m_path.c_str());
    }
}

StatusCode WebMContainer::DoInit(HostPropertyCollectionRef* props) {
    Log("Container init");
    DumpProps("container init props", props);
    TakePath(props, "init");
    return errNone;
}

StatusCode WebMContainer::DoOpen(HostPropertyCollectionRef* props) {
    Log("Container open");
    DumpProps("container open props", props);
    TakePath(props, "open");
    return errNone;
}

StatusCode WebMContainer::DoAddTrack(HostPropertyCollectionRef* props, HostPropertyCollectionRef* codecProps,
                                     IPluginTrackBase** track) {
    Log("Container add track");
    DumpProps("track props", props);
    DumpProps("track codec props", codecProps);
    TakePath(props, "track props");

    uint32_t media = 0;
    FromEither(props, codecProps, [&](IPropertyProvider* p) { return p->GetUINT32(pIOPropMediaType, media); });
    uint32_t width = 0, height = 0;
    FromEither(props, codecProps, [&](IPropertyProvider* p) { return p->GetUINT32(pIOPropWidth, width); });
    FromEither(props, codecProps, [&](IPropertyProvider* p) { return p->GetUINT32(pIOPropHeight, height); });
    uint32_t fourCC = 0;
    FromEither(props, codecProps, [&](IPropertyProvider* p) { return p->GetUINT32(pIOPropFourCC, fourCC); });
    uint32_t samplingRate = 0, channels = 0;
    FromEither(props, codecProps, [&](IPropertyProvider* p) { return p->GetUINT32(pIOPropSamplingRate, samplingRate); });
    FromEither(props, codecProps, [&](IPropertyProvider* p) { return p->GetUINT32(pIOPropNumChannels, channels); });

    bool isVideo;
    if (media & mediaVideo)
        isVideo = !(media & mediaAudio) || width > 0 || fourCC == 'vp09';
    else if (media & mediaAudio)
        isVideo = false;
    else  // not told: decide from what is there
        isVideo = (width > 0 && height > 0) || fourCC == 'vp09' || (samplingRate == 0 && channels == 0);

    if (!isVideo) {
        Log("-> audio track: accepted and discarded (this version writes video only)");
        *track = new WebMDiscardTrack(this);
        return errNone;
    }

    if (m_haveVideoTrack) {
        Log("-> extra video track: accepted and discarded (WebM output carries one video track)");
        *track = new WebMDiscardTrack(this);
        return errNone;
    }

    m_haveVideoTrack = true;
    m_width = width;
    m_height = height;
    AVRational fps{0, 1};
    if (FromEither(props, codecProps, [&](IPropertyProvider* p) { return ReadFrameRate(p, fps); })) m_fps = fps;

    int16_t v16 = 0;
    uint8_t v8 = 0;
    if (FromEither(props, codecProps, [&](IPropertyProvider* p) { return p->GetINT16(pIOColorMatrix, v16); }))
        m_colorSpace = v16;
    if (FromEither(props, codecProps, [&](IPropertyProvider* p) { return p->GetINT16(pIOPropColorPrimaries, v16); }))
        m_colorPrimaries = v16;
    if (FromEither(props, codecProps,
                   [&](IPropertyProvider* p) { return p->GetINT16(pIOTransferCharacteristics, v16); }))
        m_colorTrc = v16;
    if (FromEither(props, codecProps, [&](IPropertyProvider* p) { return p->GetUINT8(pIOPropDataRange, v8); }))
        m_colorRange = v8 == 1 ? AVCOL_RANGE_JPEG : AVCOL_RANGE_MPEG;

    Log("-> video track: %ux%u @ %d/%d fps (missing values are filled in from the first packet)", m_width, m_height,
        m_fps.num, m_fps.den);
    *track = new WebMVideoTrack(this);
    return errNone;
}

StatusCode WebMContainer::EnsureMuxer() {
    if (m_video) return errNone;
    if (m_failed) return errFail;
    m_failed = true;  // cleared on success

    if (m_path.empty()) {
        Log("ERROR: Resolve never gave the container an output path");
        return errNoParam;
    }
    if (m_width == 0 || m_height == 0) {
        Log("ERROR: unknown frame size");
        return errNoParam;
    }
    if (m_fps.num <= 0 || m_fps.den <= 0) {
        Log("WARNING: unknown frame rate, assuming 25 fps");
        m_fps = AVRational{25, 1};
    }
    m_codecTimeBase = AVRational{m_fps.den, m_fps.num};

    int ret = avformat_alloc_output_context2(&m_fmt, nullptr, "webm", m_path.c_str());
    if (ret < 0 || !m_fmt) {
        Log("ERROR: could not create WebM muxer: %s", ErrStr(ret).c_str());
        return errFail;
    }
    ret = avio_open(&m_fmt->pb, m_path.c_str(), AVIO_FLAG_WRITE);
    if (ret < 0) {
        Log("ERROR: could not open '%s' for writing: %s", m_path.c_str(), ErrStr(ret).c_str());
        return errFail;
    }

    m_video = avformat_new_stream(m_fmt, nullptr);
    if (!m_video) return errAlloc;

    AVCodecParameters* par = m_video->codecpar;
    par->codec_type = AVMEDIA_TYPE_VIDEO;
    par->codec_id = AV_CODEC_ID_VP9;
    par->width = static_cast<int>(m_width);
    par->height = static_cast<int>(m_height);
    // YUVA420P is what makes FFmpeg's Matroska writer set AlphaMode=1 on the
    // track; the metadata key does the same on builds that look for it.
    par->format = AV_PIX_FMT_YUVA420P;
    m_video->time_base = m_codecTimeBase;
    m_video->avg_frame_rate = m_fps;
    m_video->r_frame_rate = m_fps;
    av_dict_set(&m_video->metadata, "alpha_mode", "1", 0);

    // Untagged files make browsers guess; Rec.709 is what an SDR Resolve
    // timeline delivers unless it said otherwise.
    par->color_space = m_colorSpace > 0 && m_colorSpace != AVCOL_SPC_RESERVED ? static_cast<AVColorSpace>(m_colorSpace)
                                                                             : AVCOL_SPC_BT709;
    par->color_primaries = m_colorPrimaries > 0 && m_colorPrimaries != AVCOL_PRI_UNSPECIFIED
                               ? static_cast<AVColorPrimaries>(m_colorPrimaries)
                               : AVCOL_PRI_BT709;
    par->color_trc = m_colorTrc > 0 && m_colorTrc != AVCOL_TRC_UNSPECIFIED
                         ? static_cast<AVColorTransferCharacteristic>(m_colorTrc)
                         : AVCOL_TRC_BT709;
    par->color_range = m_colorRange != AVCOL_RANGE_UNSPECIFIED ? static_cast<AVColorRange>(m_colorRange)
                                                               : AVCOL_RANGE_MPEG;

    AVDictionary* opts = nullptr;
    // Leave room to write the seek index at the front so browsers can seek at once.
    av_dict_set(&opts, "reserve_index_space", "50000", 0);
    ret = avformat_write_header(m_fmt, &opts);
    av_dict_free(&opts);
    if (ret < 0) {
        Log("ERROR: could not write WebM header: %s", ErrStr(ret).c_str());
        return errFail;
    }

    m_failed = false;
    Log("Writing WebM: VP9+alpha %ux%u @ %d/%d fps -> %s", m_width, m_height, m_fps.num, m_fps.den, m_path.c_str());
    return errNone;
}

StatusCode WebMContainer::WriteVideo(HostBufferRef* buf) {
    if (buf == nullptr) return errNone;  // end-of-stream marker, nothing to write

    char* raw = nullptr;
    size_t size = 0;
    if (!buf->LockBuffer(&raw, &size) || raw == nullptr) {
        Log("ERROR: could not lock packet buffer");
        return errFail;
    }
    const uint8_t* data = reinterpret_cast<const uint8_t*>(raw);

    const uint8_t* colour = data;
    size_t colourSize = size;
    const uint8_t* side = nullptr;
    size_t sideSize = 0;

    if (size >= kFrameHeaderSize && memcmp(data, kFrameMagic, 4) == 0) {
        const uint32_t cs = ReadLE32(data + 4);
        const uint32_t ss = ReadLE32(data + 8);
        const uint32_t w = ReadLE32(data + 12);
        const uint32_t h = ReadLE32(data + 16);
        const uint32_t fn = ReadLE32(data + 20);
        const uint32_t fd = ReadLE32(data + 24);
        if (kFrameHeaderSize + static_cast<size_t>(cs) + ss > size) {
            buf->UnlockBuffer();
            Log("ERROR: corrupt packet framing (%u + %u > %zu)", cs, ss, size);
            return errFail;
        }
        if (!m_video) {  // fill in anything Resolve didn't tell us
            if (m_width == 0 || m_height == 0) {
                m_width = w;
                m_height = h;
            }
            if ((m_fps.num <= 0 || m_fps.den <= 0) && fn && fd) m_fps = AVRational{static_cast<int>(fn), static_cast<int>(fd)};
        }
        colour = data + kFrameHeaderSize;
        colourSize = cs;
        side = colour + cs;
        sideSize = ss;
    } else if (m_packets == 0) {
        Log("WARNING: packets are not framed - is the encoder another codec? Writing colour only.");
    }

    if (EnsureMuxer() != errNone) {
        buf->UnlockBuffer();
        return errFail;
    }

    AVPacket* pkt = av_packet_alloc();
    if (!pkt || av_new_packet(pkt, static_cast<int>(colourSize)) < 0) {
        buf->UnlockBuffer();
        av_packet_free(&pkt);
        return errAlloc;
    }
    memcpy(pkt->data, colour, colourSize);
    if (sideSize) {
        uint8_t* sd = av_packet_new_side_data(pkt, AV_PKT_DATA_MATROSKA_BLOCKADDITIONAL, sideSize);
        if (sd) {
            memcpy(sd, side, sideSize);
            ++m_alphaPackets;
        }
    }
    buf->UnlockBuffer();

    int64_t pts = m_packets, dts = AV_NOPTS_VALUE;
    buf->GetINT64(pIOPropPTS, pts);
    if (!buf->GetINT64(pIOPropDTS, dts)) dts = pts;
    uint8_t key = 0;
    buf->GetUINT8(pIOPropIsKeyFrame, key);

    // VP9 here never reorders frames, so keep DTS strictly increasing.
    if (m_lastDts != INT64_MIN && dts <= m_lastDts) dts = m_lastDts + 1;
    if (pts < dts) pts = dts;
    m_lastDts = dts;

    pkt->pts = pts;
    pkt->dts = dts;
    pkt->duration = 1;
    pkt->stream_index = m_video->index;
    if (key) pkt->flags |= AV_PKT_FLAG_KEY;
    av_packet_rescale_ts(pkt, m_codecTimeBase, m_video->time_base);

    const int ret = av_interleaved_write_frame(m_fmt, pkt);
    av_packet_free(&pkt);
    if (ret < 0) {
        Log("ERROR: writing packet %lld failed: %s", static_cast<long long>(m_packets), ErrStr(ret).c_str());
        return errFail;
    }
    ++m_packets;
    return errNone;
}

StatusCode WebMContainer::DoClose() {
    if (m_closed) return errNone;
    m_closed = true;
    Log("Container close");

    StatusCode result = errNone;
    if (!m_video && m_haveVideoTrack && !m_failed && m_width && m_height) EnsureMuxer();  // empty render
    if (m_fmt) {
        if (m_video) {
            const int ret = av_write_trailer(m_fmt);
            if (ret < 0) {
                Log("ERROR: could not finalise WebM: %s", ErrStr(ret).c_str());
                result = errFail;
            }
        }
        if (m_fmt->pb) avio_closep(&m_fmt->pb);
        avformat_free_context(m_fmt);
        m_fmt = nullptr;
    }
    Log("Container closed: %lld video packets, %lld with alpha -> %s", static_cast<long long>(m_packets),
        static_cast<long long>(m_alphaPackets), m_path.c_str());
    if (m_packets > 0 && m_alphaPackets == 0) {
        Log("WARNING: no alpha data was written. The file will play but will be opaque.");
    }
    return result;
}

// ---------------------------------------------------------------------------
// Tracks
// ---------------------------------------------------------------------------

StatusCode WebMVideoTrack::DoWrite(HostBufferRef* buf) { return m_owner->WriteVideo(buf); }

StatusCode WebMDiscardTrack::DoWrite(HostBufferRef* buf) {
    if (buf && m_dropped++ == 0) Log("Discarding audio (WebM output here is video-only)");
    return errNone;
}

}  // namespace webmalpha
