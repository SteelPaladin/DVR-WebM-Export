// mock_resolve: a stand-in for DaVinci Resolve's side of the IOPlugin API.
//
// It loads the .dvcp exactly the way Resolve does (dlopen + pluginInit), lists
// codecs/containers, shows the encoder settings UI, then "renders" a synthetic
// clip with a soft-edged moving matte through the codec and container,
// producing a real .webm file. This lets us test the full plugin path without
// Resolve. It does NOT prove what Resolve itself sends; that is what the
// plugin's diagnostic log is for.
//
// usage: mock_resolve <plugin.dvcp> <out.webm> [rgba|ayuv] [frames] [width] [height]

#include <dlfcn.h>

#include <algorithm>
#include <cmath>
#include <cstdarg>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <map>
#include <set>
#include <string>
#include <vector>

#include "IOPluginDefs.h"
#include "IOPluginProps.h"

using namespace IOPlugin;

// ---------------------------------------------------------------------------
// Host objects
// ---------------------------------------------------------------------------

struct HostObj {
    int refs = 1;
    virtual ~HostObj() = default;
};

struct Prop {
    PropertyType type = propTypeNull;
    std::vector<uint8_t> bytes;
    int count = 0;
};

struct PropBag : HostObj {
    std::map<std::string, Prop> props;
};

struct Buffer : PropBag {
    std::vector<uint8_t> data;
    bool locked = false;
};

struct List : HostObj {
    std::vector<PropBag*> items;
};

struct Callback : HostObj {
    ObjectRef track = nullptr;  // container track to forward packets to
};

static std::set<HostObj*> g_live;
static APIContext g_plugin = {0, nullptr};
static int g_packetsForwarded = 0;
static int g_errors = 0;

static size_t TypeSize(PropertyType t) {
    switch (t) {
        case propTypeInt8:
        case propTypeUInt8:
        case propTypeString: return 1;
        case propTypeInt16:
        case propTypeUInt16: return 2;
        case propTypeInt32:
        case propTypeUInt32: return 4;
        case propTypeInt64:
        case propTypeUInt64:
        case propTypeDouble: return 8;
        default: return 0;
    }
}

template <typename T>
static T* Track(T* obj) {
    g_live.insert(obj);
    return obj;
}

static HostObj* AsHost(ObjectRef ref) {
    HostObj* h = static_cast<HostObj*>(ref);
    return g_live.count(h) ? h : nullptr;
}

static void SetProp(PropBag* bag, const char* id, PropertyType type, const void* value, int count) {
    Prop p;
    p.type = type;
    p.count = count;
    const size_t n = TypeSize(type) * count;
    p.bytes.resize(n + 1, 0);  // +1 keeps strings NUL-terminated
    if (n) memcpy(p.bytes.data(), value, n);
    bag->props[id] = p;
}

static void SetU32(PropBag* b, const char* id, uint32_t v) { SetProp(b, id, propTypeUInt32, &v, 1); }
static void SetU8(PropBag* b, const char* id, uint8_t v) { SetProp(b, id, propTypeUInt8, &v, 1); }
static void SetI16(PropBag* b, const char* id, int16_t v) { SetProp(b, id, propTypeInt16, &v, 1); }
static void SetI32(PropBag* b, const char* id, int32_t v) { SetProp(b, id, propTypeInt32, &v, 1); }
static void SetI64(PropBag* b, const char* id, int64_t v) { SetProp(b, id, propTypeInt64, &v, 1); }
static void SetStr(PropBag* b, const char* id, const std::string& s) {
    SetProp(b, id, propTypeString, s.data(), static_cast<int>(s.size()));
}

static const Prop* GetProp(PropBag* b, const char* id) {
    auto it = b->props.find(id);
    return it == b->props.end() ? nullptr : &it->second;
}

static std::string PropStr(PropBag* b, const char* id) {
    const Prop* p = GetProp(b, id);
    if (!p || p->type != propTypeString) return "";
    std::string s(reinterpret_cast<const char*>(p->bytes.data()), p->count);
    for (auto& c : s)
        if (c == '\0') c = '|';
    return s;
}

static long long PropInt(PropBag* b, const char* id, long long fallback = -1) {
    const Prop* p = GetProp(b, id);
    if (!p || p->count < 1) return fallback;
    const uint8_t* d = p->bytes.data();
    switch (p->type) {
        case propTypeInt8: return *reinterpret_cast<const int8_t*>(d);
        case propTypeUInt8: return *d;
        case propTypeInt16: return *reinterpret_cast<const int16_t*>(d);
        case propTypeUInt16: return *reinterpret_cast<const uint16_t*>(d);
        case propTypeInt32: return *reinterpret_cast<const int32_t*>(d);
        case propTypeUInt32: return *reinterpret_cast<const uint32_t*>(d);
        case propTypeInt64: return *reinterpret_cast<const int64_t*>(d);
        default: return fallback;
    }
}

static void Release(HostObj* h) {
    if (--h->refs == 0) {
        g_live.erase(h);
        delete h;
    }
}

// ---------------------------------------------------------------------------
// The host's message handler (what Resolve implements)
// ---------------------------------------------------------------------------

static StatusCode HostHandle(MessageID msg, ...) {
    va_list a;
    va_start(a, msg);
    StatusCode err = errUnsupported;

    switch (msg) {
        case msgCreate: {
            const unsigned char* uuid = va_arg(a, const unsigned char*);
            ObjectRef* out = va_arg(a, ObjectRef*);
            if (!memcmp(uuid, UUID_PropertyCollection, 16)) {
                *out = Track(new PropBag());
                err = errNone;
            } else if (!memcmp(uuid, UUID_UnpinnedBuffer, 16) || !memcmp(uuid, UUID_PinnedBuffer, 16)) {
                *out = Track(new Buffer());
                err = errNone;
            }
            break;
        }
        case msgRetain:
        case msgRelease: {
            ObjectRef obj = va_arg(a, ObjectRef);
            int* newRef = va_arg(a, int*);
            if (HostObj* h = AsHost(obj)) {
                if (msg == msgRetain) {
                    *newRef = ++h->refs;
                } else {
                    *newRef = h->refs - 1;
                    Release(h);
                }
                err = errNone;
            } else {
                // A plugin-owned object: forward to the plugin.
                err = g_plugin.pHandleMessage(msg, obj, newRef);
            }
            break;
        }
        case msgResolveLog: {
            (void)va_arg(a, int);
            const char* text = va_arg(a, const char*);
            (void)text;  // plugin also writes its own log file; keep stdout readable
            err = errNone;
            break;
        }
        case msgPropSet: {
            PropBag* bag = dynamic_cast<PropBag*>(AsHost(va_arg(a, ObjectRef)));
            const char* id = va_arg(a, const char*);
            PropertyType type = static_cast<PropertyType>(va_arg(a, int));
            const void* value = va_arg(a, const void*);
            int count = va_arg(a, int);
            if (bag) {
                SetProp(bag, id, type, value, count);
                err = errNone;
            } else {
                err = errInvalidParam;
            }
            break;
        }
        case msgPropGet: {
            PropBag* bag = dynamic_cast<PropBag*>(AsHost(va_arg(a, ObjectRef)));
            const char* id = va_arg(a, const char*);
            PropertyType* type = va_arg(a, PropertyType*);
            const void** value = va_arg(a, const void**);
            int* count = va_arg(a, int*);
            const Prop* p = bag ? GetProp(bag, id) : nullptr;
            if (p) {
                *type = p->type;
                *value = p->bytes.data();
                *count = p->count;
                err = errNone;
            } else {
                *type = propTypeNull;
                *value = nullptr;
                *count = 0;
                err = errNoParam;
            }
            break;
        }
        case msgPropClear: {
            if (PropBag* bag = dynamic_cast<PropBag*>(AsHost(va_arg(a, ObjectRef)))) {
                bag->props.clear();
                err = errNone;
            }
            break;
        }
        case msgListAppend: {
            List* list = dynamic_cast<List*>(AsHost(va_arg(a, ObjectRef)));
            PropBag* item = dynamic_cast<PropBag*>(AsHost(va_arg(a, ObjectRef)));
            if (list && item) {
                ++item->refs;
                list->items.push_back(item);
                err = errNone;
            }
            break;
        }
        case msgBufferResize: {
            Buffer* b = dynamic_cast<Buffer*>(AsHost(va_arg(a, ObjectRef)));
            size_t n = va_arg(a, size_t);
            if (b) {
                b->data.resize(n);
                err = errNone;
            }
            break;
        }
        case msgBufferLock: {
            Buffer* b = dynamic_cast<Buffer*>(AsHost(va_arg(a, ObjectRef)));
            char** ptr = va_arg(a, char**);
            size_t* size = va_arg(a, size_t*);
            if (b) {
                b->locked = true;
                *ptr = reinterpret_cast<char*>(b->data.data());
                *size = b->data.size();
                err = errNone;
            }
            break;
        }
        case msgBufferUnlock: {
            if (Buffer* b = dynamic_cast<Buffer*>(AsHost(va_arg(a, ObjectRef)))) {
                b->locked = false;
                err = errNone;
            }
            break;
        }
        case msgCodecProcessData: {
            // Codec -> host: an encoded packet. Resolve passes these on to the
            // container track; so do we.
            Callback* cb = dynamic_cast<Callback*>(AsHost(va_arg(a, ObjectRef)));
            ObjectRef pkt = va_arg(a, ObjectRef);
            if (cb && cb->track) {
                err = g_plugin.pHandleMessage(msgTrackWrite, cb->track, pkt);
                if (err != errNone) {
                    fprintf(stderr, "track write failed: %d\n", err);
                    ++g_errors;
                }
                ++g_packetsForwarded;
            }
            break;
        }
        case msgCodecAcceptFramePTS: {
            (void)va_arg(a, ObjectRef);
            (void)va_arg(a, int64_t);
            bool* accept = va_arg(a, bool*);
            *accept = true;
            err = errNone;
            break;
        }
        default:
            fprintf(stderr, "host: unhandled message 0x%08x\n", msg);
            break;
    }
    va_end(a);
    return err;
}

// ---------------------------------------------------------------------------
// Synthetic test picture: a soft-edged disc moving across a transparent frame,
// coloured with a gradient, plus a 50%-opaque bar along the bottom.
// Returns straight (un-premultiplied) RGBA.
// ---------------------------------------------------------------------------

static void MakeRGBA(std::vector<uint8_t>& out, int w, int h, uint32_t stride, int frame, int frames) {
    out.assign(static_cast<size_t>(stride) * h, 0);
    const double t = frames > 1 ? static_cast<double>(frame) / (frames - 1) : 0.0;
    const double cx = w * (0.25 + 0.5 * t), cy = h * 0.45, r = h * 0.25;
    for (int y = 0; y < h; ++y) {
        uint8_t* row = out.data() + static_cast<size_t>(y) * stride;
        for (int x = 0; x < w; ++x) {
            const double d = std::hypot(x - cx, y - cy);
            double alpha = std::clamp((r - d) / (r * 0.15), 0.0, 1.0);  // soft edge
            if (y > h * 0.85 && y < h * 0.95) alpha = std::max(alpha, 0.5);
            uint8_t* px = row + x * 4;
            px[0] = static_cast<uint8_t>(255.0 * x / (w - 1));
            px[1] = static_cast<uint8_t>(255.0 * y / (h - 1));
            px[2] = 200;
            px[3] = static_cast<uint8_t>(alpha * 255.0 + 0.5);
        }
    }
}

// Same picture as AYUV (A,Y,U,V byte order), BT.709 limited range.
static void MakeAYUV(std::vector<uint8_t>& out, int w, int h, uint32_t stride, int frame, int frames) {
    std::vector<uint8_t> rgba;
    MakeRGBA(rgba, w, h, stride, frame, frames);
    out.assign(rgba.size(), 0);
    for (int y = 0; y < h; ++y) {
        for (int x = 0; x < w; ++x) {
            const uint8_t* s = rgba.data() + static_cast<size_t>(y) * stride + x * 4;
            uint8_t* d = out.data() + static_cast<size_t>(y) * stride + x * 4;
            const double R = s[0] / 255.0, G = s[1] / 255.0, B = s[2] / 255.0;
            const double Y = 0.2126 * R + 0.7152 * G + 0.0722 * B;
            const double Cb = (B - Y) / 1.8556, Cr = (R - Y) / 1.5748;
            d[0] = s[3];
            d[1] = static_cast<uint8_t>(std::lround(16 + 219 * Y));
            d[2] = static_cast<uint8_t>(std::lround(128 + 224 * Cb));
            d[3] = static_cast<uint8_t>(std::lround(128 + 224 * Cr));
        }
    }
}

// ---------------------------------------------------------------------------

static ObjectRef CreatePluginObj(const uint8_t* uuid) {
    ObjectRef obj = nullptr;
    if (g_plugin.pHandleMessage(msgCreate, uuid, &obj) != errNone) return nullptr;
    return obj;
}

static int Fail(const char* what) {
    fprintf(stderr, "FAIL: %s\n", what);
    return 1;
}

int main(int argc, char** argv) {
    if (argc < 3) {
        fprintf(stderr, "usage: %s plugin.dvcp out.webm [rgba|ayuv] [frames] [width] [height]\n", argv[0]);
        return 2;
    }
    const std::string mode = argc > 3 ? argv[3] : "rgba";
    const int frames = argc > 4 ? atoi(argv[4]) : 48;
    const int width = argc > 5 ? atoi(argv[5]) : 640;
    const int height = argc > 6 ? atoi(argv[6]) : 360;
    const uint32_t stride = width * 4 + 64;  // padded rows, like a real host may send

    void* lib = dlopen(argv[1], RTLD_NOW | RTLD_LOCAL);
    if (!lib) {
        fprintf(stderr, "dlopen: %s\n", dlerror());
        return 1;
    }
    auto init = reinterpret_cast<pluginInitFunc>(dlsym(lib, "pluginInit"));
    if (!init) return Fail("pluginInit not exported");

    APIContext host = {1, HostHandle};
    if (init(&host, &g_plugin) != errNone) return Fail("pluginInit");
    if (g_plugin.pHandleMessage(msgPluginStart) != errNone) return Fail("msgPluginStart");

    // ---- info / codecs / containers ----
    PropBag* info = Track(new PropBag());
    g_plugin.pHandleMessage(msgPluginGetInfo, info);
    printf("Plugin: %s\n", PropStr(info, pIOPropName).c_str());

    List* codecs = Track(new List());
    if (g_plugin.pHandleMessage(msgPluginListCodecs, codecs) != errNone) return Fail("list codecs");
    List* containers = Track(new List());
    if (g_plugin.pHandleMessage(msgPluginListContainers, containers) != errNone) return Fail("list containers");

    for (PropBag* c : codecs->items) {
        printf("Codec: %-24s group=%s colorModel=%lld hasAlpha=%lld threadSafe=%lld containers=[%s]\n",
               PropStr(c, pIOPropName).c_str(), PropStr(c, pIOPropGroup).c_str(), PropInt(c, pIOPropColorModel),
               PropInt(c, pIOPropHasAlpha), PropInt(c, pIOPropThreadSafe),
               PropStr(c, pIOPropContainerList).c_str());
    }
    for (PropBag* c : containers->items) {
        printf("Container: %s ext=%s mediaType=%lld\n", PropStr(c, pIOPropName).c_str(),
               PropStr(c, pIOPropContainerExt).c_str(), PropInt(c, pIOPropMediaType));
    }
    if (codecs->items.size() != 2 || containers->items.size() != 1) return Fail("unexpected codec/container count");
    if (PropInt(codecs->items[0], pIOPropHasAlpha) != 1) return Fail("codec does not declare hasAlpha=1");

    const int codecIdx = mode == "ayuv" ? 1 : 0;
    PropBag* codecInfo = codecs->items[codecIdx];
    const Prop* codecUUID = GetProp(codecInfo, pIOPropUUID);
    const Prop* contUUID = GetProp(containers->items[0], pIOPropUUID);

    // ---- settings UI ----
    PropBag* settingsIn = Track(new PropBag());
    List* ui = Track(new List());
    if (g_plugin.pHandleMessage(msgCodecSettings, codecUUID->bytes.data(), settingsIn, ui) != errNone)
        return Fail("codec settings");
    for (PropBag* e : ui->items) {
        printf("UI: %-20s type=%lld label='%s' value=%lld\n", PropStr(e, pIOPropName).c_str(),
               PropInt(e, pIOPropUIType), PropStr(e, pIOPropUILabel).c_str(), PropInt(e, pIOPropUIValue));
    }

    // ---- codec ----
    ObjectRef codec = CreatePluginObj(codecUUID->bytes.data());
    if (!codec) return Fail("create codec");

    PropBag* initProps = Track(new PropBag());
    SetU32(initProps, pIOPropWidth, width);
    SetU32(initProps, pIOPropHeight, height);
    if (g_plugin.pHandleMessage(msgCodecInit, codec, initProps) != errNone) return Fail("codec init");

    Callback* cb = Track(new Callback());
    if (g_plugin.pHandleMessage(msgCodecSetCallback, codec, cb) != errNone) return Fail("set callback");

    const std::string outPath = argv[2];
    char contDashed[64];
    const uint8_t* u = contUUID->bytes.data();
    snprintf(contDashed, sizeof(contDashed), "%02X%02X%02X%02X-%02X%02X-%02X%02X-%02X%02X-%02X%02X%02X%02X%02X%02X",
             u[0], u[1], u[2], u[3], u[4], u[5], u[6], u[7], u[8], u[9], u[10], u[11], u[12], u[13], u[14], u[15]);

    Buffer* openBuf = Track(new Buffer());
    SetU32(openBuf, pIOPropWidth, width);
    SetU32(openBuf, pIOPropHeight, height);
    const uint32_t fps[2] = {25, 1};
    SetProp(openBuf, pIOPropFrameRate, propTypeUInt32, fps, 2);
    SetU8(openBuf, pIOPropHasAlpha, 1);
    SetU8(openBuf, pIOPropDataRange, 0);
    SetI16(openBuf, pIOColorMatrix, 1);
    SetI16(openBuf, pIOPropColorPrimaries, 1);
    SetI16(openBuf, pIOTransferCharacteristics, 1);
    SetStr(openBuf, pIOPropContainerList, contDashed);
    SetStr(openBuf, pIOPropPath, outPath);
    SetI32(openBuf, "webmalpha_crf", 28);
    SetI32(openBuf, "webmalpha_speed", 4);
    if (const char* m = getenv("MOCK_MODE")) SetI32(openBuf, "webmalpha_mode", atoi(m));  // 0 fast, 1 quality
    if (g_plugin.pHandleMessage(msgCodecOpen, codec, openBuf) != errNone) return Fail("codec open");

    // ---- container ----
    // MOCK_ORDER=normal       init, open, then add tracks (fully described)
    // MOCK_ORDER=tracks-first add tracks before init/open; video track props carry
    //                         only the media type, path arrives only at open
    // MOCK_ORDER=bare         like tracks-first, but track and codec props are empty
    const char* orderEnv = getenv("MOCK_ORDER");
    const std::string order = orderEnv ? orderEnv : "normal";
    printf("Call order: %s\n", order.c_str());

    ObjectRef cont = CreatePluginObj(contUUID->bytes.data());
    if (!cont) return Fail("create container");
    PropBag* pathProps = Track(new PropBag());
    SetStr(pathProps, pIOPropPath, outPath);
    PropBag* emptyProps = Track(new PropBag());

    PropBag* trackProps = Track(new PropBag());
    if (order == "normal") {
        SetU32(trackProps, pIOPropMediaType, mediaVideo);
        SetU32(trackProps, pIOPropWidth, width);
        SetU32(trackProps, pIOPropHeight, height);
        SetProp(trackProps, pIOPropFrameRate, propTypeUInt32, fps, 2);
        SetU32(trackProps, pIOPropTrackIdx, 0);
    } else if (order == "tracks-first") {
        SetU32(trackProps, pIOPropMediaType, mediaVideo);
    }
    PropBag* videoCodecProps = order == "bare" ? Track(new PropBag()) : codecInfo;

    PropBag* audioProps = Track(new PropBag());
    SetU32(audioProps, pIOPropMediaType, mediaAudio);
    SetU32(audioProps, pIOPropSamplingRate, 48000);
    SetU32(audioProps, pIOPropNumChannels, 2);
    PropBag* audioCodec = Track(new PropBag());
    SetU32(audioCodec, pIOPropMediaType, mediaAudio);

    ObjectRef videoTrack = nullptr;
    ObjectRef audioTrack = nullptr;
    auto addTracks = [&]() -> bool {
        if (g_plugin.pHandleMessage(msgContainerAddTrack, cont, trackProps, videoCodecProps, &videoTrack) !=
                errNone ||
            !videoTrack)
            return false;
        if (g_plugin.pHandleMessage(msgContainerAddTrack, cont, audioProps, audioCodec, &audioTrack) != errNone ||
            !audioTrack)
            return false;
        return true;
    };

    if (order == "normal") {
        if (g_plugin.pHandleMessage(msgContainerInit, cont, pathProps) != errNone) return Fail("container init");
        if (g_plugin.pHandleMessage(msgContainerOpen, cont, pathProps) != errNone) return Fail("container open");
        if (!addTracks()) return Fail("add tracks");
    } else {
        if (!addTracks()) return Fail("add tracks (before open)");
        if (g_plugin.pHandleMessage(msgContainerInit, cont, emptyProps) != errNone) return Fail("container init");
        if (g_plugin.pHandleMessage(msgContainerOpen, cont, pathProps) != errNone) return Fail("container open");
    }
    cb->track = videoTrack;

    // ---- render ----
    std::vector<uint8_t> pixels;
    for (int i = 0; i < frames; ++i) {
        if (mode == "ayuv")
            MakeAYUV(pixels, width, height, stride, i, frames);
        else
            MakeRGBA(pixels, width, height, stride, i, frames);
        Buffer* frame = Track(new Buffer());
        frame->data = pixels;
        SetI64(frame, pIOPropPTS, i);
        SetU32(frame, pIOBufferStride, stride);
        const StatusCode st = static_cast<StatusCode>(g_plugin.pHandleMessage(msgCodecProcessData, codec, frame));
        if (st != errNone && st != errMoreData) return Fail("encode frame");
        Release(frame);

        // Some silent audio for the discard track.
        Buffer* audio = Track(new Buffer());
        audio->data.assign(48000 / 25 * 2 * 2, 0);
        g_plugin.pHandleMessage(msgTrackWrite, audioTrack, audio);
        Release(audio);
    }
    if (g_plugin.pHandleMessage(msgCodecFlush, codec) != errNone) return Fail("flush");
    if (g_plugin.pHandleMessage(msgContainerClose, cont) != errNone) return Fail("container close");

    int ref = 0;
    g_plugin.pHandleMessage(msgRelease, videoTrack, &ref);
    g_plugin.pHandleMessage(msgRelease, audioTrack, &ref);
    g_plugin.pHandleMessage(msgRelease, codec, &ref);
    g_plugin.pHandleMessage(msgRelease, cont, &ref);
    g_plugin.pHandleMessage(msgPluginTerminate);

    printf("Rendered %d frames -> %d packets -> %s (%d track errors)\n", frames, g_packetsForwarded, outPath.c_str(),
           g_errors);
    return g_errors ? 1 : 0;
}
