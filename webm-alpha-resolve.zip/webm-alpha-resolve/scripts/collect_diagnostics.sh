#!/usr/bin/env bash
# Gather everything needed to debug the WebM Alpha plugin into one file:
#   ~/Desktop/WebMAlpha-diagnostics.txt
#
# Run it AFTER trying a render in Resolve:
#   ./scripts/collect_diagnostics.sh

# Re-run under bash if started with "sh script.sh" (macOS sh lacks bash features)
if [ -z "${BASH_VERSION:-}" ] || (shopt -oq posix 2>/dev/null); then exec /bin/bash "$0" "$@"; fi
OUT="$HOME/Desktop/WebMAlpha-diagnostics.txt"
BUNDLE="webm_alpha_plugin.dvcp.bundle"
STANDALONE_DIR="/Library/Application Support/Blackmagic Design/DaVinci Resolve/IOPlugins"
APPSTORE_ROOT="$HOME/Library/Containers/com.blackmagic-design.DaVinciResolveAppStore/Data"
APPSTORE_DIR="$APPSTORE_ROOT/Library/Application Support/IOPlugins"

{
echo "===== WebM Alpha diagnostics $(date) ====="
echo
echo "## System"
sw_vers 2>/dev/null
echo "CPU: $(uname -m)   (translated by Rosetta: $(sysctl -n sysctl.proc_translated 2>/dev/null || echo n/a))"

echo
echo "## DaVinci Resolve installs"
APPS="$(mktemp)"
find /Applications -maxdepth 3 -name "DaVinci Resolve*.app" -type d > "$APPS" 2>/dev/null
found=0
while IFS= read -r app; do
    found=1
    ver="$(defaults read "$app/Contents/Info" CFBundleShortVersionString 2>/dev/null)"
    exe="$(defaults read "$app/Contents/Info" CFBundleExecutable 2>/dev/null)"
    archs="$(lipo -archs "$app/Contents/MacOS/$exe" 2>/dev/null)"
    sandboxed="no"
    codesign -d --entitlements - "$app" 2>/dev/null | grep -q "app-sandbox" && sandboxed="YES (App Store style)"
    libval="enforced"
    codesign -d --entitlements - "$app" 2>/dev/null | grep -q "disable-library-validation" && libval="disabled (third-party plugins allowed)"
    echo "$app"
    echo "   version $ver, binary archs: $archs, sandboxed: $sandboxed, library validation: $libval"
done < "$APPS"
rm -f "$APPS"
[ "$found" = 0 ] && echo "No DaVinci Resolve app found under /Applications"
pgrep -lf "DaVinci Resolve.app" >/dev/null 2>&1 && echo "(Resolve is currently running)"

echo
echo "## Installed IO plugins"
for d in "$STANDALONE_DIR" "$APPSTORE_DIR"; do
    if [ -d "$d" ]; then
        echo "$d:"
        ls -1 "$d" | sed 's/^/   /'
    fi
done

echo
echo "## The WebM Alpha bundle"
for d in "$STANDALONE_DIR" "$APPSTORE_DIR"; do
    b="$d/$BUNDLE"
    [ -d "$b" ] || continue
    echo "$b"
    find "$b" -print | sed 's/^/   /'
    DVCPS="$(mktemp)"
    find "$b" -name "*.dvcp" -type f > "$DVCPS"
    while IFS= read -r dvcp; do
        echo "   file:  $(file -b "$dvcp")"
        echo "   archs: $(lipo -archs "$dvcp" 2>/dev/null)"
        echo "   signature: $(codesign -dv "$dvcp" 2>&1 | grep -E 'Signature|flags' | tr '\n' ' ')"
        echo "   quarantine: $(xattr -p com.apple.quarantine "$dvcp" 2>/dev/null || echo none)"
        echo "   linked libraries:"
        otool -L "$dvcp" | tail -n +2 | while read -r lib _; do
            case "$lib" in /System/*|/usr/lib/*) is_system=1 ;; *) is_system=0 ;; esac
            if [ "$is_system" = 1 ]; then
                printf '      %s\n' "$lib"
            elif [ -e "$lib" ]; then
                printf '      %s  [ok]\n' "$lib"
            else
                printf '      %s  [MISSING]\n' "$lib"
            fi
        done
        echo "   load test:"
        if command -v python3 >/dev/null 2>&1; then
            python3 - "$dvcp" <<'PY' 2>&1 | sed 's/^/      /'
import ctypes, sys
try:
    lib = ctypes.CDLL(sys.argv[1])
    print("loads OK; pluginInit exported:", hasattr(lib, "pluginInit"))
except OSError as e:
    print("FAILED TO LOAD:", e)
PY
        else
            echo "      (python3 not available)"
        fi
    done < "$DVCPS"
    rm -f "$DVCPS"
done

echo
echo "## WebM Alpha logs"
for log in "$HOME/Library/Logs/WebMAlpha.log" "$APPSTORE_ROOT/Library/Logs/WebMAlpha.log" "/tmp/WebMAlpha.log"; do
    if [ -f "$log" ]; then
        echo "---- $log ($(wc -l < "$log") lines, showing last 400) ----"
        tail -n 400 "$log"
    else
        echo "(none at $log)"
    fi
done

echo
echo "## Resolve's own logs (lines mentioning plugins / WebM)"
for logdir in "$HOME/Library/Application Support/Blackmagic Design/DaVinci Resolve/logs" \
              "$APPSTORE_ROOT/Library/Application Support/logs"; do
    [ -d "$logdir" ] || continue
    for f in "$logdir"/*.txt "$logdir"/*.log; do
        [ -f "$f" ] || continue
        hits="$(grep -iE "webm|ioplugin|dvcp|codec plugin|encoder plugin|add video track|WebM Alpha" "$f" 2>/dev/null | tail -n 80)"
        if [ -n "$hits" ]; then
            echo "---- $f ----"
            echo "$hits"
        fi
    done
done
echo
echo "===== end ====="
} > "$OUT" 2>&1

echo "Saved: $OUT"
echo "Send that file (or paste its contents) back."
