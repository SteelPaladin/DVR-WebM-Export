#!/usr/bin/env bash
# Build the WebM Alpha plugin on macOS and install it into DaVinci Resolve Studio.
#
#   ./scripts/build_mac.sh            build + install (asks for your password to copy into /Library)
#   ./scripts/build_mac.sh --build    build only
#   ./scripts/build_mac.sh --uninstall
#
# Needs: Xcode Command Line Tools and Homebrew. The script installs cmake,
# pkg-config and ffmpeg (which includes libvpx) with Homebrew if missing.

# Re-run under bash if started with "sh script.sh" (macOS sh lacks bash features)
if [ -z "${BASH_VERSION:-}" ] || (shopt -oq posix 2>/dev/null); then exec /bin/bash "$0" "$@"; fi
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD="$ROOT/build-mac"
BUNDLE_NAME="webm_alpha_plugin.dvcp.bundle"

STANDALONE_DIR="/Library/Application Support/Blackmagic Design/DaVinci Resolve/IOPlugins"
APPSTORE_DIR="$HOME/Library/Containers/com.blackmagic-design.DaVinciResolveAppStore/Data/Library/Application Support/IOPlugins"

say() { printf '\n\033[1m%s\033[0m\n' "$*"; }

pick_install_dir() {
    if [ -d "/Applications/DaVinci Resolve/DaVinci Resolve.app" ] || [ -d "/Applications/DaVinci Resolve Studio/DaVinci Resolve.app" ]; then
        echo "$STANDALONE_DIR"
    elif [ -d "$HOME/Library/Containers/com.blackmagic-design.DaVinciResolveAppStore" ]; then
        echo "$APPSTORE_DIR"
    else
        echo "$STANDALONE_DIR"
    fi
}

uninstall() {
    for d in "$STANDALONE_DIR" "$APPSTORE_DIR"; do
        if [ -d "$d/$BUNDLE_NAME" ]; then
            say "Removing $d/$BUNDLE_NAME"
            if [[ "$d" == /Library/* ]]; then sudo rm -rf "$d/$BUNDLE_NAME"; else rm -rf "$d/$BUNDLE_NAME"; fi
        fi
    done
    echo "Uninstalled. Restart Resolve."
}

if [ "${1:-}" = "--uninstall" ]; then
    uninstall
    exit 0
fi

# --- prerequisites -----------------------------------------------------------
if ! xcode-select -p >/dev/null 2>&1; then
    say "Xcode Command Line Tools are needed. Starting the installer; re-run this script when it finishes."
    xcode-select --install || true
    exit 1
fi
if ! command -v brew >/dev/null 2>&1; then
    say "Homebrew is needed: https://brew.sh  (install it, then re-run this script)"
    exit 1
fi

for pkg in cmake pkg-config ffmpeg; do
    if ! brew list --formula "$pkg" >/dev/null 2>&1; then
        say "Installing $pkg with Homebrew"
        brew install "$pkg"
    fi
done

if ! ffmpeg -hide_banner -encoders 2>/dev/null | grep -q libvpx-vp9; then
    say "Your Homebrew ffmpeg has no libvpx-vp9 encoder; reinstall it with: brew reinstall ffmpeg"
    exit 1
fi

# --- build -------------------------------------------------------------------
say "Building"
export PKG_CONFIG_PATH="$(brew --prefix)/lib/pkgconfig:$(brew --prefix ffmpeg)/lib/pkgconfig:${PKG_CONFIG_PATH:-}"
cmake -S "$ROOT" -B "$BUILD" -DCMAKE_BUILD_TYPE=Release
cmake --build "$BUILD" -j"$(sysctl -n hw.ncpu)"

BUILT="$BUILD/$BUNDLE_NAME"
[ -d "$BUILT" ] || { echo "Build finished but $BUILT is missing"; exit 1; }
echo "Built: $BUILT"

if [ "${1:-}" = "--build" ]; then
    exit 0
fi

# --- install -----------------------------------------------------------------
if pgrep -x "Resolve" >/dev/null 2>&1; then
    say "Quit DaVinci Resolve first (it only loads plugins at launch), then press Enter."
    read -r _
fi

DEST="$(pick_install_dir)"
say "Installing to: $DEST"
if [[ "$DEST" == /Library/* ]]; then
    sudo mkdir -p "$DEST"
    sudo rm -rf "$DEST/$BUNDLE_NAME"
    sudo cp -R "$BUILT" "$DEST/"
    sudo xattr -rd com.apple.quarantine "$DEST/$BUNDLE_NAME" 2>/dev/null || true
else
    mkdir -p "$DEST"
    rm -rf "$DEST/$BUNDLE_NAME"
    cp -R "$BUILT" "$DEST/"
fi

# Fresh logs for this test run
rm -f "$HOME/Library/Logs/WebMAlpha.log" "/tmp/WebMAlpha.log" \
      "$HOME/Library/Containers/com.blackmagic-design.DaVinciResolveAppStore/Data/Library/Logs/WebMAlpha.log"

say "Done."
cat <<EOF
Next:
  1. Open DaVinci Resolve Studio.
  2. Deliver page -> Custom Export -> Format: WebM -> Codec: VP9 Alpha (RGBA)
  3. Tick "Export Alpha", set Alpha Mode to "Straight", render a short clip.
  4. Check the result:   $ROOT/scripts/check_webm.sh /path/to/render.webm
  5. Whether it worked or not, run:  $ROOT/scripts/collect_diagnostics.sh
     and send back ~/Desktop/WebMAlpha-diagnostics.txt

Note: the plugin links to Homebrew's FFmpeg. If 'brew upgrade' moves FFmpeg to
a new major version, re-run this script to rebuild.
EOF
