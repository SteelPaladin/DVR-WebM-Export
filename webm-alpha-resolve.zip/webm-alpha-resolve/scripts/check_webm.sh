#!/usr/bin/env bash
# Check that a .webm really has a working alpha channel.
#
#   ./scripts/check_webm.sh render.webm
#
# Prints the stream info and alpha statistics, and writes two preview images
# next to the file: <name>_frame.png (with transparency) and
# <name>_checker.png (composited over a checkerboard so you can see it).

# Re-run under bash if started with "sh script.sh" (macOS sh lacks bash features)
if [ -z "${BASH_VERSION:-}" ] || (shopt -oq posix 2>/dev/null); then exec /bin/bash "$0" "$@"; fi
set -euo pipefail

IN="${1:?usage: check_webm.sh file.webm}"
BASE="${IN%.*}"

echo "== Stream =="
# The libvpx decoder is the one that understands VP9 alpha; FFmpeg's built-in
# vp9 decoder silently ignores it.
ffmpeg -hide_banner -c:v libvpx-vp9 -i "$IN" 2>&1 | grep -E "Duration|Video:|ALPHA_MODE|alpha_mode" || true

echo
echo "== Alpha channel =="
if ! ffprobe -v error -show_entries stream_tags -of default=nw=1 "$IN" | grep -qi "alpha_mode=1"; then
    echo "NO AlphaMode flag on the track: players will treat this file as opaque."
fi

STATS="$(ffmpeg -hide_banner -nostats -c:v libvpx-vp9 -i "$IN" \
    -vf "alphaextract,signalstats,metadata=print:key=lavfi.signalstats.YMIN,metadata=print:key=lavfi.signalstats.YMAX" \
    -f null - 2>&1 || true)"
AMIN="$(echo "$STATS" | grep -o 'YMIN=[0-9]*' | cut -d= -f2 | sort -n | head -1 || true)"
AMAX="$(echo "$STATS" | grep -o 'YMAX=[0-9]*' | cut -d= -f2 | sort -n | tail -1 || true)"

if [ -z "$AMIN" ]; then
    echo "Could not read an alpha plane at all: no transparency in this file."
    exit 1
fi
echo "Alpha range across the clip: $AMIN (most transparent) .. $AMAX (most opaque)"
if [ "$AMIN" -ge 250 ]; then
    echo "RESULT: alpha is present but everything is opaque. Resolve probably sent no real alpha"
    echo "        (check 'Export Alpha' is ticked) - see ~/Library/Logs/WebMAlpha.log"
else
    echo "RESULT: transparency present."
fi

DUR="$(ffprobe -v error -show_entries format=duration -of csv=p=0 "$IN")"
MID="$(awk -v d="$DUR" 'BEGIN { printf "%.3f", d / 2 }')"
ffmpeg -hide_banner -v error -y -c:v libvpx-vp9 -ss "$MID" -i "$IN" -frames:v 1 -pix_fmt rgba "${BASE}_frame.png"
SIZE="$(ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=x:p=0 "$IN")"
ffmpeg -hide_banner -v error -y \
    -f lavfi -i "color=c=gray:s=${SIZE},format=gray,geq=lum='if(mod(floor(X/24)+floor(Y/24)\,2)\,190\,120)'" \
    -i "${BASE}_frame.png" \
    -filter_complex "[0][1]overlay=format=auto,format=rgb24" -frames:v 1 "${BASE}_checker.png"

echo
echo "Previews: ${BASE}_frame.png  ${BASE}_checker.png"
